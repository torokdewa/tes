<?php

/**
=====================
+ PANDORA ID SENDER +
=====================

|==> + HOW TO USE +
|
|==> GET DEVICE ID FIRST 'php device.php' ON COMMAND LINE
|==> LOGIN TO DASHBOARD AND ADD YOUR DEVICE ID
|==> PUT YOUR LICENSE ON license.ini
|==> IF THERE IS A CONFIG THAT YOU DON'T USE THEN "LEAVE IT BLANK"

 **/

$pandora_config = [

    // MAILER SETTINGS
    "TimeZone"          => "Asia/Jakarta", // DEFAULT MAILER TIMEZONE ( REFERENCE : https://www.w3schools.com/php/php_ref_timezones.asp )
    "ColorMode"         => true, // CLI COLOR MODE ( true/false )
    "Connection"        => "1", // SENDING CONNECTION/THREAD
    "Delay"             => "0", // SENDING DELAY
    "Priority"          => "3", // EMAIL PRIORITY ( 1 = High / 3 = Normal / 5 = low OR LEAVE BLANK IF NOT USING )
    "Encoding"          => "base64", // EMAIL ENCODING ( 7bit/8bit/base64/binary/quoted-printable )
    "Charset"           => "utf-8", // EMAIL CHARSET ( us-ascii/iso-8859-1/utf-8 )
    "Blank-Charset"     => "utf-8", // BLANK CHARACTER CHARSET ( REFERENCE : https://pandora-id.vip/blankcharset.txt )
    "Message-ID"        => "", // CUSTOM MESSAGE-ID ( LEAVE BLANK IF NOT USING )
    "X-Mailer"          => "", // CUSTOM X-MAILER ( LEAVE BLANK IF NOT USING )

    // SMTP SETTINGS
    "SMTPFile"          => "smtp.txt", // SMTP FILE NAME
    "Host"              => "email-smtp.us-west-1.amazonaws.com", // SMTP HOST
    "Hostname"          => "", // SMTP HOSTNAME ( LEAVE BLANK IF NOT USING )
    "Secure"            => "tls", // SMTP SECURE TYPE ( ssl/tls OR LEAVE BLANK IF NOT USING )
    "Port"              => "587", // SMTP PORT

    // EMAIL LIST SETTINGS
    "MailistFile"       => "list.txt", // EMAIL LIST FILE NAME
    "ClearDuplicate"    => false, // CLEAR DUPLICATE EMAIL LIST ( true/false )
    "LogFailed"         => true, // LOG SEND FAILED EMAIL LIST ( true/false )

    // LETTER SETTINGS
    "RandomLetter"      => false, // RANDOM LETTER SELECTION ON LETTER FOLDER ( true/false )
    "LetterFile"        => "letter.html", // LETTER FILE NAME
    "LetterType"        => "html", // LETTER TYPE ( html/text )
    "LetterEncrypt"     => "", // LETTER ENCRYPT ( unicode/unicodebold/unicodeitalic/punnycode/entities OR LEAVE BLANK IF NOT USING)

    // ALTERNATIVE SETTINGS
    "Alternative"       => "", // ALTERNATIVE TYPE ( auto/custom OR LEAVE BLANK IF NOT USING )
    "AlternativeFile"   => "alt.txt", // ALTERNATIVE FILE NAME
    "EncryptAlt"        => "", // ALT ENCRYPT ( unicode/unicodebold/unicodeitalic/punnycode OR LEAVE BLANK IF NOT USING)

    // ATTACHMENT SETTINGS
    "RandomAttachment"  => false, // RANDOM ATTACHMENT SELECTION ON ATTACHMENT FOLDER ( true/false )
    "AttachmentFile"    => "", // ATTACHMENT FILE NAME ( LEAVE BLANK IF NOT USING )
    "AttachmentType"    => "ics", // ATTACHMENT TYPE ( html/default )
    "AttachmentName"    => "calendar.ics", // ATTACHMENT CUSTOM NAME
    "EncryptNames"      => "", // ATTACHMENT NAME ENCRYPT ( unicode/unicodebold/unicodeitalic/punnycode OR LEAVE BLANK IF NOT USING)
    "AttachmentEncoding"=> "base64", // ATTACHMENT ENCODING ( quoted-printable/base64 )

    // IMAGE SETTINGS
    "ImageFile"         => "", // IMAGE FILE NAME ( LEAVE BLANK IF NOT USING )
    "ImageName"         => "IMG_##number_mix_8##.png", // IMAGE CUSTOM NAME
    "EncryptName"       => "", // IMAGE NAME ENCRYPT ( unicode/unicodebold/unicodeitalic/punnycode OR LEAVE BLANK IF NOT USING)
    "ImageEncoding"     => "base64", // IMAGE ENCODING ( quoted-printable/base64 )

    // CALENDAR EVENT SETTINGS
    "CalendarEvent"     => false, // ADD RANDOM iCal EVENT ( NOT WORK WHILE USING EMBEDDED IMAGE ) ( true/false )

    // LINK SETTINGS
    "Link"              => "https://seleccion.etika.com.bo/info.php?##email##?c5f577366893459291c27a5baa1b39e9?region=us-east-1", // LINK
    "LinkParameter"     => false, // ADD RANDOM LINK PARAMETER ( true/false )
    "EncryptLink"       => true, // ENCRYPT LINK WITH ENTITIES ( true/false )

    // CUSTOM RANDOM SETTINGS
    "CustomRandom"      => [ // HINT ( ##custom1## WILL BECOME ##letternumber_low_10## or ##number_mix_10## )
        "##custom1##"	=> "##letternumber_low_10##|##number_mix_10##",
        "##custom2##"	=> "value1|value2|value3|value4|value5",
        "##custom3##"	=> "value1|value2|value3|value4|value5",
    ],

    // CUSTOM BOUNDARY SETTINGS
    "Boundary"          => "default", // BOUNDARY TYPE ( custom = CUSTOM BOUNDARY NAME, default = DEFAULT BOUNDARY NAME )
    "BoundaryName"      => "_----------=_MCPart_##number_mix_9##", // CUSTOM BOUNDARY NAME

    // CUSTOM HEADER SETTINGS
    "Header"            => false, // CUSTOM HEADER ( true/false )
    "HeaderData"        => array( // CUSTOM HEADER VALUE ( USAGE : "Name|Value" )
        "x-CSA-Compliance-Source|SFMC",
        "List-ID|<##number_mix_7##.xt.local>",
        "X-CSA-Complaints|csa-complaints@eco.de",
        "X-SFMC-Stack|##number_mix_1##",
        "x-job|##number_mix_7##_##number_mix_6##",
    ),

    // CUSTOM DKIM SETTINGS
    "DKIM"              => "default", // ( default = USE DEFAULT SMTP DKIM / custom = USE CUSTOM DKIM)
    "DKIM-Domain"       => "outlook.live.com", // CUSTOM DKIM DOMAIN
    "DKIMKey-File"      => "private.key", // YOUR DKIM PRIVATE KEY ( HINT : https://dkimcore.org/tools/ )
    "DKIM-Selector"     => "1628007943", // YOUR DKIM SELECTOR NUMBER/ID
];

$pandora_send = [

    // EXPERIMENT SETTINGS
    "SendTwoTimes"      => false, // SEND EMAIL TWO TIMES PER LIST
    "EmailTest"         => "", // EMAIL FOR TEST ( LEAVE BLANK IF NOT USING )
    "TestAfter"         => "1000", // TEST AFTER SPECIFIED EMAIL SENT

    // RETURN PATH SETTINGS
    "ReturnPath"        => "", // CUSTOM RETURN-PATH ( LEAVE BLANK IF NOT USING )

    // BCC SETTINGS
    "BccMode"           => false, // BCC MODE ( true/false )
    "BccTo"             => "", // ADD TO IN BCC MODE ( LEAVE BLANK IF NOT USING )

    // REPLY TO SETTINGS
    "ReplyTo-Mail"      => "", // REPLY TO EMAIL ( LEAVE BLANK IF NOT USING )
    "ReplyTo-Name"      => "", // REPLY TO NAME ( LEAVE BLANK IF NOT USING )
    "ReplyTo-Encrypt"   => "", // REPLY TO NAME ENCRYPT ( unicode/unicodebold/unicodeitalic/punnycode OR LEAVE BLANK IF NOT USING)

    // FROM SETTINGS 
    "FromName"          => "Noreply", // FROM NAME ( LEAVE BLANK IF NOT USING )
    "FromName-Encrypt"  => "", // FROM NAME ENCRYPT ( unicode/unicodebold/unicodeitalic/punnycode OR LEAVE BLANK IF NOT USING)
    "FromMail"          => "noreply-auth@chaineus.org", // FROM MAIL

    // SUBJECT SETTINGS
    "Subject"           => "", // SUBJECT ( LEAVE BLANK IF NOT USING )
    "Subject-Encrypt"   => "", // FROM NAME ENCRYPT ( unicode/unicodebold/unicodeitalic/punnycode OR LEAVE BLANK IF NOT USING)

];

