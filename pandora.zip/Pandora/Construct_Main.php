<?php
error_reporting(E_ALL);

require_once __DIR__ ."/../Modules/SMTP.php";
require_once  __DIR__ ."/../Modules/Exception.php";
require_once  __DIR__ ."/../Modules/Function.php";
require_once  __DIR__ ."/../Modules/Mailer.php";
require_once  __DIR__ ."/../settings.php";

use PandoraMailer\PandoraMailer\PandoraMailer;
use PandoraMailer\PandoraMailer\Exception;

function PandoraSend($list, $smtp, $pandora_config, $pandora_send)
{
    $mail = new PandoraMailer(true);
    try
    {
        $m = $pandora_config["ColorMode"];
        $r = "red";

        $getsmtp = explode(",", $smtp);
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->SMTPAuth = true;
        $mail->SMTPKeepAlive = true;
        $mail->Host = $pandora_config["Host"];

        $mail->Username = $getsmtp[0];
        $mail->Password = $getsmtp[1];

        if (!empty($pandora_config["Secure"]))
        {
            $mail->SMTPSecure = $pandora_config["Secure"];
        } else {
            $mail->SMTPAutoTLS = false;
            $mail->SMTPSecure = false;
        }
        $mail->Port = $pandora_config["Port"];

        $encodings = customrandom($pandora_config["Encoding"], $pandora_config["CustomRandom"]);
        $charsets = customrandom($pandora_config["Charset"], $pandora_config["CustomRandom"]);

        $mail->Encoding = $encodings;
        $mail->CharSet = $charsets;

        if (!empty($pandora_config["Priority"]))
        {
            $prioritys = customrandom($pandora_config["Priority"], $pandora_config["CustomRandom"]);
            $mail->Priority = $prioritys;
        }
        $mail->DKIM_selector = "default";

        $key = "";

        if ($list != null)
        {
            foreach ($list as $key)
            {
                $donothing = "";
                echo $donothing;
            }
        }
        $timezone = $pandora_config["TimeZone"];
        $imagecid = "cid:" . date('YntGis');
        $smtps = $getsmtp[0];
        $link = $pandora_config["Link"];
        if ($pandora_config["LinkParameter"] == true)
        {
            $linkparam = "yes";
        } else {
            $linkparam = "no";
        }

        if ($pandora_config["EncryptLink"] == true)
        {
            $encryptlink = "yes";
        } else {
            $encryptlink = "no";
        }

        $encryptstring = "no";
        $encryptattachment = "no";
        $type = "normal";

        if ($pandora_config["Boundary"] == "custom")
        {
            $boundaryset = customrandom($pandora_config["Boundary"], $pandora_config["CustomRandom"]);
            if (!empty($pandora_config["BoundaryName"]))
            {
                $boundaryname = customrandom($pandora_config["BoundaryName"], $pandora_config["CustomRandom"]);

                $boundaryname = pandora($boundaryname, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $encryptstring, $encryptattachment, $type);

            } else {
                die(c($r, "\xd    Error : Invalid boundary name!", $m) . "\xd\xa\xd");
            }
            $mail->customboundaryset = $boundaryset;
            $mail->customboundaryname = $boundaryname;
        } else {
            $mail->customboundaryset = "default";
            $mail->customboundaryname = "";
        }

        $blankcharset = customrandom($pandora_config["Blank-Charset"], $pandora_config["CustomRandom"]);

        if (!empty($pandora_send["FromName"]))
        {
            $fromnameencrypt = customrandom($pandora_send["FromName-Encrypt"], $pandora_config["CustomRandom"]);
            $fromname = customrandom($pandora_send["FromName"], $pandora_config["CustomRandom"]);

            if (preg_match("/##blankbase/i", $fromname))
            {
                $fromname = pandora($fromname, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $fromnameencrypt, $encryptattachment, $type);

                $fromname = "=?" . $blankcharset . "?B?" . base64_encode($fromname) . "?=";
            }
            elseif (preg_match("/##blankquoted/i", $fromname))
            {
                $fromname = pandora($fromname, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $fromnameencrypt, $encryptattachment, $type);

                $fromname = "=?" . $blankcharset . "?Q?" . $fromname . "?=";
            } else {
                $fromname = pandora($fromname, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $fromnameencrypt, $encryptattachment, $type);

            }
        } else {
            $fromname = "";
        }

        if (!empty($pandora_send["FromMail"]))
        {
            $frommail = customrandom($pandora_send["FromMail"], $pandora_config["CustomRandom"]);

            $frommail = pandora($frommail, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $encryptstring, $encryptattachment, $type);


            $mail->setFrom($frommail, $fromname);
        } else {
            $frommail = "";
        }

        if (!empty($pandora_send["Subject"]))
        {
            $subjectencrypt = customrandom($pandora_send["Subject-Encrypt"], $pandora_config["CustomRandom"]);
            $subject = customrandom($pandora_send["Subject"], $pandora_config["CustomRandom"]);

            if (preg_match("/##blankbase/i", $subject))
            {
                $subject = pandora($subject, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $subjectencrypt, $encryptattachment, $type);

                $subject = "=?" . $blankcharset . "?B?" . base64_encode($subject) . "?=";
            }
            elseif (preg_match("/##blankquoted/i", $subject))
            {
                $subject = pandora($subject, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $subjectencrypt, $encryptattachment, $type);

                $subject = "=?" . $blankcharset . "?Q?" . $subject . "?=";
            } else {
                $subject = pandora($subject, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $subjectencrypt, $encryptattachment, $type);

            }
        } else {
            $subject = "";
        }

        $mail->Subject = $subject;

        if (!empty($pandora_send["ReturnPath"]))
        {
            $returnpath = customrandom($pandora_send["ReturnPath"], $pandora_config["CustomRandom"]);
            $returnpath = sendtags($fromname, $frommail, $subject, $returnpath);

            $returnpath = pandora($returnpath, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $encryptstring, $encryptattachment, $type);

            $mail->Sender = $returnpath;
        }

        if (!empty($pandora_config["Message-ID"]))
        {
            $messageid = customrandom($pandora_config["Message-ID"], $pandora_config["CustomRandom"]);
            $messageid = sendtags($fromname, $frommail, $subject, $messageid);

            $messageid = pandora($messageid, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $encryptstring, $encryptattachment, $type);

            $mail->MessageID = $messageid;
        }

        if (!empty($pandora_config["X-Mailer"]))
        {
            $xmailer = customrandom($pandora_config["X-Mailer"], $pandora_config["CustomRandom"]);
            $xmailer = sendtags($fromname, $frommail, $subject, $xmailer);

            $xmailer = pandora($xmailer, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $encryptstring, $encryptattachment, $type);

            $mail->XMailer = $xmailer;
        }

        if (!empty($pandora_config["Hostname"]))
        {
            $hostnames = customrandom($pandora_config["Hostname"], $pandora_config["CustomRandom"]);
            $hostnames = sendtags($fromname, $frommail, $subject, $hostnames);

            $hostnames = pandora($hostnames, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $encryptstring, $encryptattachment, $type);

            $mail->Hostname = $hostnames;
        }

        if (!empty($pandora_send["BccTo"]))
        {
            $bccto = customrandom($pandora_send["BccTo"], $pandora_config["CustomRandom"]);
            $bccto = sendtags($fromname, $frommail, $subject, $bccto);

            $bccto = pandora($bccto, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $encryptstring, $encryptattachment, $type);

        } else {
            $bccto = "";
        }

        if (!empty($pandora_send["ReplyTo-Mail"]))
        {
            $replytomail = customrandom($pandora_send["ReplyTo-Mail"], $pandora_config["CustomRandom"]);
            $replytomail = sendtags($fromname, $frommail, $subject, $replytomail);

            $replytomail = pandora($replytomail, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $encryptstring, $encryptattachment, $type);


            if (!empty($pandora_send["ReplyTo-Name"]))
            {
                $replytoencrypt = customrandom($pandora_send["ReplyTo-Encrypt"], $pandora_config["CustomRandom"]);
                $replytoname = customrandom($pandora_send["ReplyTo-Name"], $pandora_config["CustomRandom"]);
                $replytoname = sendtags($fromname, $frommail, $subject, $replytoname);

                $replytoname = pandora($replytoname, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $replytoencrypt, $encryptattachment, $type);

            } else {
                $replytoname = "";
            }
        } else {
            $replytomail = "";
            $replytoname = "";
        }

        if ($pandora_send["BccMode"] == true)
        {
            $mail->addBCC($key);
            if (!empty($bccto))
            {
                $mail->addAddress($bccto);
            }
        } else {
            $mail->addAddress($key);
        }

        if (!empty($replytomail))
        {
            if (!empty($replytoname))
            {
                $mail->addReplyTo($replytomail, $replytoname);
            } else {
                $mail->addReplyTo($replytomail);
            }
        }

        if ($pandora_config["Header"] == true)
        {
            if (!empty($pandora_config["HeaderData"]))
            {
                foreach ($pandora_config["HeaderData"] as $headerdata)
                {
                    $headername = explode("|", $headerdata)[0];
                    $headervalue = explode("|", $headerdata)[1];
                    $headername = customrandom($headername, $pandora_config["CustomRandom"]);
                    $headername = sendtags($fromname, $frommail, $subject, $headername);
                    $headervalue = customrandom($headervalue, $pandora_config["CustomRandom"]);
                    $headervalue = sendtags($fromname, $frommail, $subject, $headervalue);

                    $headername = pandora($headername, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $encryptstring, $encryptattachment, $type);
                    $headervalue = pandora($headervalue, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $encryptstring, $encryptattachment, $type);

                    $mail->AddCustomHeader($headername, $headervalue);
                }
            }
        }

        if ($pandora_config["CalendarEvent"] == true)
        {
            $mail->Ical = iCalGenerate();
        }

        if (!empty($pandora_config["ImageFile"]))
        {
            if (!empty($pandora_config["EncryptName"]))
            {
                $encryptname = customrandom($pandora_config["EncryptName"], $pandora_config["CustomRandom"]);
            } else {
                $encryptname = "no";
            }
            $imagesname = customrandom($pandora_config["ImageName"], $pandora_config["CustomRandom"]);
            $imagesname = sendtags($fromname, $frommail, $subject, $imagesname);

            $imagesname = pandora($imagesname, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $encryptname, $encryptattachment, $type);

            $imagesencoding = customrandom($pandora_config["ImageEncoding"], $pandora_config["CustomRandom"]);
            $imagefilename = customrandom($pandora_config["ImageFile"], $pandora_config["CustomRandom"]);
            $mail->addEmbeddedImage("Image/" . $imagefilename, explode(":", $imagecid)[1], $imagesname, $imagesencoding);
        }

        if (!empty($pandora_config["LetterFile"]))
        {
            if ($pandora_config["RandomLetter"] == true)
            {
                $letterfile = glob("Letter/*");
                $letterfiles = $letterfile[rand(0, count($letterfile) -1)];
                $letter = file_get_contents($letterfiles);
            } else {
                $letterfilename = customrandom($pandora_config["LetterFile"], $pandora_config["CustomRandom"]);
                $letter = file_get_contents("Letter/" . $letterfilename) or die(c($r, "\xd    Error : Letter not found!", $m) . "\xd\xa\xd");
            }

            if ($pandora_config["LetterType"] == "html")
            {
                $mail->isHTML(true);
            }

            if ($pandora_config["LetterEncrypt"] != null)
            {
                $encryptletter = customrandom($pandora_config["LetterEncrypt"], $pandora_config["CustomRandom"]);
            } else {
                $encryptletter = "no";
            }

            $letter = customrandom($letter, $pandora_config["CustomRandom"]);
            $letter = pandora($letter, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $encryptletter, $encryptattachment, $type);
            $mail->AllowEmpty = true;
            $mail->Body = $letter;
        } else {
            $letter = "";
        }

        if (!empty($pandora_config["AttachmentFile"]))
        {
            if ($pandora_config["EncryptNames"] != null)
            {
                $encryptnames = $pandora_config["EncryptNames"];
            } else {
                $encryptnames = "no";
            }

            if (!empty($pandora_config["AttachmentName"]))
            {
                $attachmentname = customrandom($pandora_config["AttachmentName"], $pandora_config["CustomRandom"]);
                $attachmentname = sendtags($fromname, $frommail, $subject, $attachmentname);
            } else {
                die(c($r, "\xd    Error : Invalid attachment name!", $m) . "\xd\xa\xd");
            }

            $attachmentname = explode(".", $attachmentname);

            $attachmentname[0] = pandora($attachmentname[0], $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $encryptnames, $encryptattachment, $type);

            $attachmentencoding = customrandom($pandora_config["AttachmentEncoding"], $pandora_config["CustomRandom"]);

            if ($pandora_config["RandomAttachment"] == true)
            {
                $attachmentfile = glob("Attachment/*");
                $attachmentfiles = $attachmentfile[rand(0, count($attachmentfile) -1)];
            } else {
                $attachmentfilesname = customrandom($pandora_config["AttachmentFile"], $pandora_config["CustomRandom"]);
                $attachmentfiles = "Attachment/" . $attachmentfilesname;
            }

            if ($pandora_config["AttachmentType"] == "html")
            {
                $attachmentcontent = file_get_contents($attachmentfiles);
                $attachmentcontent = customrandom($attachmentcontent, $pandora_config["CustomRandom"]);
                $attachmentcontent = sendtags($fromname, $frommail, $subject, $attachmentcontent);
                $attachmentcontent = pandora($attachmentcontent, $timezone, $key, $imagecid, $smtps, $link, $linkparam, "no", $encryptstring, "yes", $type);

                file_put_contents("cache/attachmentcontent.html", $attachmentcontent);
                $attachmentcontent = "cache/attachmentcontent.html";
                $mail->addAttachment($attachmentcontent, $attachmentname[0] . "." . $attachmentname[1], $attachmentencoding);
            } else {
                $mail->addAttachment($attachmentfiles, $attachmentname[0] . "." . $attachmentname[1], $attachmentencoding);
            }
        }

        if (!empty($pandora_config["Alternative"]))
        {
            if ($pandora_config["Alternative"] == "auto")
            {
                $mail->AltBody = strip_tags($letter);
            }
            elseif ($pandora_config["Alternative"] == "custom")
            {
                if (!empty($pandora_config["EncryptAlt"]))
                {
                    $encryptalt = customrandom($pandora_config["EncryptAlt"], $pandora_config["CustomRandom"]);
                } else {
                    $encryptalt = "no";
                }
                $altfilename = customrandom($pandora_config["AlternativeFile"], $pandora_config["CustomRandom"]);
                $altfile = file_get_contents("Alternative/" . $altfilename) or die(c($r, "\xd    Error : Letter not found!", $m) . "\xd\xa\xd");
                $altfile = customrandom($altfile, $pandora_config["CustomRandom"]);
                $altfile = sendtags($fromname, $frommail, $subject, $altfile);
                $altfile = pandora($altfile, $timezone, $key, $imagecid, $smtps, $link, $linkparam, "no", $encryptalt, $encryptattachment, $type);
                $mail->AltBody = $altfile;
            }
        }

        if ($pandora_config["DKIM"] != "default")
        {
            $dkimdomain = customrandom($pandora_config["DKIM-Domain"], $pandora_config["CustomRandom"]);
            $dkimdomain = sendtags($fromname, $frommail, $subject, $dkimdomain);
            $dkimdomain = pandora($dkimdomain, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $encryptstring, $encryptattachment, $type);
            $dkimkey = customrandom($pandora_config["DKIMKey-File"], $pandora_config["CustomRandom"]);
            $dkimselector = customrandom($pandora_config["DKIM-Selector"], $pandora_config["CustomRandom"]);
            $dkimselector = sendtags($fromname, $frommail, $subject, $dkimselector);

            $dkimselector = pandora($dkimselector, $timezone, $key, $imagecid, $smtps, $link, $linkparam, $encryptlink, $encryptstring, $encryptattachment, $type);


            $mail->DKIM_domain = $dkimdomain;
            $mail->DKIM_private = "Dkim Key/" . $dkimkey;
            $mail->DKIM_selector = $dkimselector;
        }

        $mail->send();
        $mail->clearAddresses();

        return array(
            "status"    => "success",
            "info"      => "",
            "from"   => $fromname . " <" . $frommail . ">",
            "subject"   => $subject,
        );

    } catch (Exception $e) {
        if ($pandora_config["LogFailed"] == true)
        {
            file_put_contents("Log/" . date("D d M Y") . ".txt", implode("\r\n", $list).PHP_EOL, FILE_APPEND);
        }

        return array(
            "status"    => "fail",
            "info"      => $e->getMessage(),
            "from"      => "",
            "subject"   => "",
        );
    }
}