<?php
error_reporting(E_ALL);
function getrandom($type)
{
    switch ($type)
    {
        case 'randomdomain':
            $data = array( 'id', 'my', 'sg', 'tw', 'th', 'kr', 'jp', 'it', 'uk', 'ch', 'fr', 'at', 'au', 'br', 'ca', 'de', 'dk', 'es', 'eu', 'hk', 'hu', 'nl', 'nz', 'ph', 'pt', 'us'
            );
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'useragent':
            $data = array("Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/" . rand(38, 56) . ".0", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" . rand(38, 56) . ".0.3071.115 Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/37.0.2062.94 Chrome/37.0.2062.94 Safari/537.36", "Mozilla/5.0 (iPad; CPU OS 8_4_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H321 Safari/600.1.4", "Mozilla/5.0 (iPhone; CPU iPhone OS 8_4_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H321 Safari/600.1.4", "Mozilla/5.0 (Linux; U; Android 4.4.3; en-us; KFTHWI Build/KTU84M) AppleWebKit/537.36 (KHTML, like Gecko) Silk/3.68 like Chrome/39.0.2171.93 Safari/537.36", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:40.0) Gecko/20100101 Firefox/40.0", "Mozilla/5.0 (X11; CrOS armv7l 7077.134.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.156 Safari/537.36"
            );
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'ip':
            $result = "" . mt_rand(0, 255) . "." . mt_rand(0, 255) . "." . mt_rand(0, 255) . "." . mt_rand(0, 255);
            break;

        case 'pcos':
            $data = array("Windows 10", "Windows 8", "Windows 7", "Windows Server 2016", "Windows Server 2012", "Ubuntu 18.04 LTS", "Ubuntu 20.04 LTS", "Mac OS 10.15", "Mac OS Mojave", "Mac OS High Sierra", "CentOS", "Debian"
            );
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'pcbrowser':
            $data = array("Chrome", "Firefox", "Safari", "Edge", "Opera"
            );
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'androiddevice':
            $data = array( "Samsung Galaxy A51", "Samsung Galaxy A71", "Xiaomi Redmi Note 9 Pro", "Xiaomi Redmi Note 9 Pro", "Samsung Galaxy S20 Ultra", "Xiaomi Redmi Note 9", "Samsung Galaxy M31", "OnePlus 8 Pro", "OnePlus Nord", "Xiaomi Redmi Note 9S", "Realme 6 Pro", "Samsung Galaxy A21s", "Xiaomi Redmi 9", "Samsung Galaxy Note20 Ultra", "Xiaomi Mi 10 Pro 5G", "Samsung Galaxy S20", "Samsung Galaxy S10 Lite", "Samsung Galaxy Note10 Lite", "Samsung Galaxy A31"
            );
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'androidos':
            $data = array( "Android 10", "Pie 9", "Oreo 8.1", "Oreo 8.0", "Nougat 7.1", "Nougat 7.0", "Marshmallow 6.0"
            );
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'androidbrowser':
            $data = array( "Brave", "Dolphin", "DuckDuckGO", "Ecosia", "Firefox", "Chrome", "Kiwi", "Opera", "Samsung Internet", "Stargon", "Surfy", "Tor", "Vivaldi"
            );
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'appleapps':
            $data = array( "Minecraft", "Heads Up!", "HotSchedules", "Bloons TD 6", "Procreate Pocket", "Geometry Dash", "Plague Inc.", "Monopoly", "Grand Theft Auto: San Andreas", "True Skate", "Facetune", "Papa's Freezeria To Go!", "Terraria", "Bloons TD 5", "Shadowrocket", "Dark Sky Weather", "TouchRetouch", "Five Nights at Freddy's", "The Wonder Weeks", "Incredibox", "75 Hard", "Papa's Mocharia To Go!", "The Game of Life 2", "Stardew Valley", "Screen Mirroring+ for Roku", "SkyView®", "a new life.", "Earn to Die 2", "Tiny Wings", "Five Nights at Freddy's 2"
            );
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'applepc':
            $data = array( "MacBook Air M1", "iMac", "MacBook Pro", "Mac mini", "iMac Pro"
            );
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'applephones':
            $data = array( "iPhone 7", "iPhone 7+", "iPhone 8", "iPhone 8+", "iPhone X", "iPhone Xr", "iPhone 11", "iPhone 11 Pro", "iPhone 11 Pro Max", "iPhone 12", "iPhone 12 Mini", "iPhone 12", "iPhone 12 Pro", "iPhone 12 Pro Max"
            );
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'ios':
            $data = array( "iOS 13.3", "iOS 12.1", "iOS 11.2", "iOS 14.4"
            );
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'appletab':
            $data = array( "iPad Pro", "iPad 10.2", "iPad Air", "iPad mini"
            );
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'browser':
            $data = array( "Mozilla Firefox", "Microsoft Edge", "Google Chrome", "Opera", "Vivaldi"
            );
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'country':
            $data = array( "Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bonaire", "Bosnia and Herzegovina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Democratic Republic of the Congo", "Cook Islands", "Costa Rica", "Croatia", "Cuba", "CuraÃ§ao", "Cyprus", "Czech Republic", "CÃ´te d'Ivoire", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guernsey", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard Island and McDonald Mcdonald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran, Islamic Republic of", "Iraq", "Ireland", "Isle of Man", "Israel", "Italy", "Jamaica", "Japan", "Jersey", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macao", "Macedonia, the Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montenegro", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Palestine, State of", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Romania", "Russian Federation", "Rwanda", "Reunion", "Saint Barthelemy", "Saint Helena", "Saint Kitts and Nevis", "Saint Lucia", "Saint Martin (French part)", "Saint Pierre and Miquelon", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Sint Maarten (Dutch part)", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "South Sudan", "Spain", "Sri Lanka", "Sudan", "Suriname", "Svalbard and Jan Mayen", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "United Republic of Tanzania", "Thailand", "Timor-Leste", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Viet Nam", "British Virgin Islands", "US Virgin Islands", "Wallis and Futuna", "Western Sahara", "Yemen", "Zambia", "Zimbabwe", "Aland Islands"
            );
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'city':
            $data = array( "Beijing", "New Delhi", "Tokyo", "Kinshasa", "Moscow", "Jakarta", "Seoul", "Cairo", "Mexico City", "London", "Dhaka", "Lima", "Tehran", "Bangkok", "Hanoi", "Riyadh", "Hong Kong", "Bogotá", "Baghdad", "Santiago", "Singapore", "Ankara", "Berlin", "Damascus", "Algiers", "Madrid", "Pyongyang", "Kabul", "Nairobi", "Addis Ababa", "Buenos Aires", "Rome", "Kyiv", "Yaoundé", "Taipei", "Brasília", "Amman", "Luanda", "Guatemala City", "Pretoria", "Paris", "Tashkent", "Baku", "Havana", "Phnom Penh", "Bucharest", "Khartoum", "Caracas", "Brazzaville", "Rabat"
            );
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'countrycity':
            $data = array( "China, Beijing", "India, New Delhi", "Japan, Tokyo", "DR Congo, Kinshasa", "Russia, Moscow", "Indonesia, Jakarta", "South Korea, Seoul", "Egypt, Cairo", "Mexico, Mexico City", "United Kingdom, London", "Bangladesh, Dhaka", "Peru, Lima", "Iran, Tehran", "Thailand, Bangkok", "Vietnam, Hanoi", "Saudi Arabia, Riyadh", "Hong Kong, Hong Kong", "Colombia, Bogotá", "Iraq, Baghdad", "Chile, Santiago", "Singapore, Singapore", "Turkey, Ankara", "Germany, Berlin", "Syria, Damascus", "Algeria, Algiers", "Spain, Madrid", "North Korea, Pyongyang", "Afghanistan, Kabul", "Kenya, Nairobi", "Ethiopia, Addis Ababa", "Argentina, Buenos Aires", "Italy, Rome", "Ukraine, Kyiv", "Cameroon, Yaoundé", "Taiwan, Taipei", "Brazil, Brasília", "Jordan, Amman", "Angola, Luanda", "Guatemala, Guatemala City", "South Africa, Pretoria", "France, Paris", "Uzbekistan, Tashkent", "Azerbaijan, Baku", "Cuba, Havana", "Cambodia, Phnom Penh", "Romania, Bucharest", "Sudan, Khartoum", "Venezuela, Caracas", "Congo, Brazzaville", "Morocco, Rabat"
            );
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'blank1':
            $data = array("͏", "‌", "‍", "⁪", "⁫", "⁬", "⁭", "⁮", "⁯");
            shuffle($data);
            $result = $data[array_rand($data)];
            break;

        case 'blank2':
            $data = array("͏", "‌", "‍", "⁪", "⁫", "⁬", "⁭", "⁮", "⁯");
            shuffle($data);
            $result = $data[array_rand($data)];
            break;

        case 'blank3':
            $data = array("͏", "⁪", "‌", "‍", "⁫", "⁬", "⁭", "⁮", "⁯");
            shuffle($data);
            $result = $data[array_rand($data)];
            break;

        case 'blank4':
            $data = array("͏", "‌", "‍", "⁪", "⁫", "⁬", "⁭", "⁮", "⁯");
            shuffle($data);
            $result = $data[array_rand($data)];
            break;

        case 'blank5':
            $data = array("͏", "‌", "‍", "⁪", "⁫", "⁬", "⁭", "⁮", "⁯");
            shuffle($data);
            $result = $data[array_rand($data)];
            break;

        case 'blank6':
            $data = array("͏", "‌", "‍", "⁪", "⁫", "⁬", "⁭", "⁮", "⁯");
            shuffle($data);
            $result = $data[array_rand($data)];
            break;

        case 'blank7':
            $data = array("͏", "‌", "‍", "⁪", "⁫", "⁬", "⁭", "⁮", "⁯");
            shuffle($data);
            $result = $data[array_rand($data)];
            break;

        case 'blank8':
            $data = array("͏", "‌", "‍", "⁪", "⁫", "⁬", "⁭", "⁮", "⁯");
            shuffle($data);
            $result = $data[array_rand($data)];
            break;

        case 'blank9':
            $data = array("͏", "‌", "‍", "⁪", "⁫", "⁬", "⁭", "⁮", "⁯");
            shuffle($data);
            $result = $data[array_rand($data)];
            break;

        case 'blank10':
            $data = array("‍", "͏", "⁪", "⁫", "‌", "⁬", "⁭", "⁮", "⁯");
            shuffle($data);
            $result = $data[array_rand($data)];
            break;


        case 'blankq1':
            $data = array("=CD=8F", "=C2=AD", "=E1=9E=B4", "=E1=9E=B5", "=E2=80=8C", "=E2=80=8D", "=E2=80=8E", "=E2=81=AA", "=E2=81=AB", "=E2=81=AC", "=E2=81=AD", "=E2=81=AE", "=E2=81=AF");
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'blankq2':
            $data = array("=C2=AD", "=CD=8F", "=E1=9E=B4", "=E1=9E=B5", "=E2=80=8C", "=E2=80=8D", "=E2=80=8E", "=E2=81=AA", "=E2=81=AB", "=E2=81=AC", "=E2=81=AD", "=E2=81=AE", "=E2=81=AF");
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'blankq3':
            $data = array("=CD=8F", "=E1=9E=B4", "=C2=AD", "=E1=9E=B5", "=E2=80=8C", "=E2=80=8D", "=E2=80=8E", "=E2=81=AA", "=E2=81=AB", "=E2=81=AC", "=E2=81=AD", "=E2=81=AE", "=E2=81=AF");
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'blankq4':
            $data = array("=CD=8F", "=E1=9E=B4", "=E1=9E=B5", "=C2=AD", "=E2=80=8C", "=E2=80=8D", "=E2=80=8E", "=E2=81=AA", "=E2=81=AB", "=E2=81=AC", "=E2=81=AD", "=E2=81=AE", "=E2=81=AF");
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'blankq5':
            $data = array("=CD=8F", "=E1=9E=B4", "=E1=9E=B5", "=E2=80=8C", "=C2=AD", "=E2=80=8D", "=E2=80=8E", "=E2=81=AA", "=E2=81=AB", "=E2=81=AC", "=E2=81=AD", "=E2=81=AE", "=E2=81=AF");
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'blankq6':
            $data = array("=CD=8F", "=E1=9E=B4", "=E1=9E=B5", "=E2=80=8C", "=E2=80=8D", "=C2=AD", "=E2=80=8E", "=E2=81=AA", "=E2=81=AB", "=E2=81=AC", "=E2=81=AD", "=E2=81=AE", "=E2=81=AF");
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'blankq7':
            $data = array("=CD=8F", "=E1=9E=B4", "=E1=9E=B5", "=E2=80=8C", "=E2=80=8D", "=E2=80=8E", "=C2=AD", "=E2=81=AA", "=E2=81=AB", "=E2=81=AC", "=E2=81=AD", "=E2=81=AE", "=E2=81=AF");
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'blankq8':
            $data = array("=CD=8F", "=E1=9E=B4", "=E1=9E=B5", "=E2=80=8C", "=E2=80=8D", "=E2=80=8E", "=E2=81=AA", "=C2=AD", "=E2=81=AB", "=E2=81=AC", "=E2=81=AD", "=E2=81=AE", "=E2=81=AF");
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'blankq9':
            $data = array("=CD=8F", "=E1=9E=B4", "=E1=9E=B5", "=E2=80=8C", "=E2=80=8D", "=E2=80=8E", "=E2=81=AA", "=E2=81=AB", "=C2=AD", "=E2=81=AC", "=E2=81=AD", "=E2=81=AE", "=E2=81=AF");
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case 'blankq10':
            $data = array("=CD=8F", "=E1=9E=B4", "=E1=9E=B5", "=E2=80=8C", "=E2=80=8D", "=E2=80=8E", "=E2=81=AA", "=E2=81=AB", "=E2=81=AC", "=C2=AD", "=E2=81=AD", "=E2=81=AE", "=E2=81=AF");
            shuffle($data);
            $result = $data[array_rand($data) ];
            break;

        case "md51":
            $result = md5(substr(str_shuffle("abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ") , 1, 21));
            break;

        case "md52":
            $result = md5(substr(str_shuffle("abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ") , 1, 22));
            break;

        case "md53":
            $result = md5(substr(str_shuffle("abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ") , 1, 23));
            break;

        case "md54":
            $result = md5(substr(str_shuffle("abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ") , 1, 24));
            break;

        case "md55":
            $result = md5(substr(str_shuffle("abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ") , 1, 25));
            break;

        case "md56":
            $result = md5(substr(str_shuffle("abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ") , 1, 26));
            break;

        case "md57":
            $result = md5(substr(str_shuffle("abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ") , 1, 27));
            break;

        case "md58":
            $result = md5(substr(str_shuffle("abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ") , 1, 28));
            break;

        case "md59":
            $result = md5(substr(str_shuffle("abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ") , 1, 29));
            break;

        case "md510":
            $result = md5(substr(str_shuffle("abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ") , 1, 30));
            break;

        default:
            $result = false;
            break;
    }

    return $result;
}

function formatter($data, $type)
{
    $strip = array(
        "~<.*?>(*SKIP)(*FAIL)|a~","~<.*?>(*SKIP)(*FAIL)|b~","~<.*?>(*SKIP)(*FAIL)|c~","~<.*?>(*SKIP)(*FAIL)|d~","~<.*?>(*SKIP)(*FAIL)|e~","~<.*?>(*SKIP)(*FAIL)|f~","~<.*?>(*SKIP)(*FAIL)|g~","~<.*?>(*SKIP)(*FAIL)|h~","~<.*?>(*SKIP)(*FAIL)|i~","~<.*?>(*SKIP)(*FAIL)|j~","~<.*?>(*SKIP)(*FAIL)|k~","~<.*?>(*SKIP)(*FAIL)|l~","~<.*?>(*SKIP)(*FAIL)|m~","~<.*?>(*SKIP)(*FAIL)|n~","~<.*?>(*SKIP)(*FAIL)|o~","~<.*?>(*SKIP)(*FAIL)|p~","~<.*?>(*SKIP)(*FAIL)|q~","~<.*?>(*SKIP)(*FAIL)|r~","~<.*?>(*SKIP)(*FAIL)|s~","~<.*?>(*SKIP)(*FAIL)|t~","~<.*?>(*SKIP)(*FAIL)|u~","~<.*?>(*SKIP)(*FAIL)|v~","~<.*?>(*SKIP)(*FAIL)|w~","~<.*?>(*SKIP)(*FAIL)|x~","~<.*?>(*SKIP)(*FAIL)|y~","~<.*?>(*SKIP)(*FAIL)|z~","~<.*?>(*SKIP)(*FAIL)|A~","~<.*?>(*SKIP)(*FAIL)|B~","~<.*?>(*SKIP)(*FAIL)|C~","~<.*?>(*SKIP)(*FAIL)|D~","~<.*?>(*SKIP)(*FAIL)|E~","~<.*?>(*SKIP)(*FAIL)|F~","~<.*?>(*SKIP)(*FAIL)|G~","~<.*?>(*SKIP)(*FAIL)|H~","~<.*?>(*SKIP)(*FAIL)|I~","~<.*?>(*SKIP)(*FAIL)|J~","~<.*?>(*SKIP)(*FAIL)|K~","~<.*?>(*SKIP)(*FAIL)|L~","~<.*?>(*SKIP)(*FAIL)|M~","~<.*?>(*SKIP)(*FAIL)|N~","~<.*?>(*SKIP)(*FAIL)|O~","~<.*?>(*SKIP)(*FAIL)|P~","~<.*?>(*SKIP)(*FAIL)|Q~","~<.*?>(*SKIP)(*FAIL)|R~","~<.*?>(*SKIP)(*FAIL)|S~","~<.*?>(*SKIP)(*FAIL)|T~","~<.*?>(*SKIP)(*FAIL)|U~","~<.*?>(*SKIP)(*FAIL)|V~","~<.*?>(*SKIP)(*FAIL)|W~","~<.*?>(*SKIP)(*FAIL)|X~","~<.*?>(*SKIP)(*FAIL)|Y~","~<.*?>(*SKIP)(*FAIL)|Z~","~<.*?>(*SKIP)(*FAIL)|1~","~<.*?>(*SKIP)(*FAIL)|2~","~<.*?>(*SKIP)(*FAIL)|3~","~<.*?>(*SKIP)(*FAIL)|4~","~<.*?>(*SKIP)(*FAIL)|5~","~<.*?>(*SKIP)(*FAIL)|6~","~<.*?>(*SKIP)(*FAIL)|7~","~<.*?>(*SKIP)(*FAIL)|8~","~<.*?>(*SKIP)(*FAIL)|9~","~<.*?>(*SKIP)(*FAIL)|0~"
    );
    $unicodenormal = array(
        "\xf0\x9d\x96\272","\360\235\x96\xbb","\360\235\x96\274","\360\x9d\226\275","\xf0\x9d\226\xbe","\360\x9d\x96\xbf","\xf0\x9d\x97\x80","\xf0\x9d\227\201","\xf0\235\227\202","\xf0\235\x97\x83","\360\235\x97\204","\360\235\x97\205","\xf0\x9d\x97\206","\360\x9d\x97\x87","\xf0\x9d\227\210","\xf0\235\227\x89","\xf0\235\x97\212","\xf0\235\227\213","\360\x9d\227\x8c","\360\235\227\215","\360\x9d\227\x8e","\360\235\x97\x8f","\360\x9d\x97\x90","\xf0\235\227\x91","\360\x9d\x97\222","\360\235\x97\223","\360\235\226\240","\xf0\235\x96\xa1","\xf0\x9d\226\242","\360\x9d\x96\243","\xf0\x9d\226\xa4","\360\235\x96\245","\360\x9d\x96\246","\360\x9d\x96\247","\360\235\226\250","\360\235\226\251","\360\235\x96\xaa","\360\235\x96\xab","\360\x9d\226\254","\360\235\x96\255","\360\235\x96\256","\360\235\226\xaf","\xf0\235\226\xb0","\360\x9d\226\261","\360\235\x96\xb2","\xf0\x9d\226\263","\xf0\x9d\226\xb4","\360\235\x96\265","\360\x9d\x96\xb6","\360\x9d\x96\xb7","\xf0\235\x96\270","\360\x9d\x96\271","\xf0\235\237\243","\xf0\235\x9f\244","\xf0\235\x9f\245","\xf0\x9d\237\xa6","\360\235\237\xa7","\360\x9d\x9f\250","\xf0\x9d\237\251","\360\235\x9f\xaa","\360\235\x9f\253","\xf0\235\237\242"
    );
    $unicodebold = array(
        "\360\x9d\227\256","\360\x9d\x97\257","\xf0\x9d\x97\260","\xf0\x9d\227\xb1","\xf0\x9d\227\262","\360\x9d\x97\xb3","\xf0\235\x97\264","\xf0\x9d\227\265","\360\x9d\x97\266","\360\x9d\x97\xb7","\xf0\x9d\227\270","\xf0\235\x97\271","\xf0\x9d\x97\272","\360\x9d\x97\273","\360\x9d\227\274","\360\235\x97\xbd","\360\235\227\276","\xf0\235\227\xbf","\360\x9d\x98\200","\xf0\x9d\x98\201","\xf0\x9d\x98\202","\xf0\x9d\230\x83","\360\x9d\230\204","\360\x9d\230\205","\xf0\x9d\230\x86","\xf0\235\x98\x87","\xf0\x9d\x97\224","\xf0\235\227\225","\xf0\235\227\x96","\xf0\235\227\227","\xf0\235\x97\x98","\360\x9d\227\231","\xf0\x9d\x97\x9a","\360\235\x97\233","\xf0\235\227\234","\360\x9d\227\235","\xf0\x9d\227\x9e","\xf0\x9d\x97\x9f","\xf0\x9d\227\240","\xf0\x9d\227\xa1","\xf0\x9d\x97\242","\360\x9d\227\xa3","\360\235\x97\xa4","\360\x9d\x97\xa5","\360\x9d\x97\246","\360\235\227\xa7","\360\x9d\x97\250","\360\235\227\xa9","\xf0\x9d\227\252","\360\x9d\227\253","\xf0\x9d\227\254","\360\x9d\227\255","\xf0\x9d\x9f\255","\360\235\x9f\256","\xf0\235\237\xaf","\360\x9d\237\260","\360\x9d\237\xb1","\360\235\237\xb2","\360\235\237\263","\xf0\235\237\264","\360\235\237\xb5","\xf0\x9d\237\254"
    );
    $unicodeitalic = array(
        "\xf0\x9d\x98\242","\360\x9d\x98\xa3","\360\235\230\xa4","\xf0\235\230\245","\360\x9d\x98\246","\360\x9d\230\xa7","\360\x9d\230\250","\xf0\235\230\251","\xf0\235\230\xaa","\xf0\235\230\253","\360\235\230\xac","\xf0\x9d\x98\255","\360\235\230\xae","\xf0\x9d\230\xaf","\360\235\230\xb0","\360\235\x98\xb1","\xf0\235\230\262","\xf0\x9d\230\xb3","\360\235\x98\264","\xf0\x9d\x98\265","\360\235\x98\xb6","\xf0\x9d\230\xb7","\xf0\235\x98\270","\xf0\235\230\271","\xf0\x9d\230\xba","\360\x9d\x98\273","\xf0\235\230\210","\360\x9d\230\x89","\360\235\230\212","\360\235\x98\x8b","\360\235\x98\x8c","\xf0\x9d\x98\x8d","\360\235\230\x8e","\360\x9d\230\217","\xf0\235\230\x90","\xf0\235\230\x91","\xf0\x9d\230\x92","\360\235\230\223","\360\x9d\x98\x94","\360\x9d\230\x95","\xf0\235\230\226","\360\235\230\x97","\360\235\x98\x98","\360\235\x98\x99","\360\235\230\x9a","\360\235\230\233","\xf0\x9d\230\234","\360\x9d\x98\x9d","\360\235\230\236","\360\x9d\x98\x9f","\xf0\x9d\230\xa0","\xf0\235\x98\241","\xf0\x9d\x9f\243","\xf0\x9d\x9f\xa4","\360\235\237\245","\360\x9d\237\246","\xf0\x9d\x9f\xa7","\xf0\x9d\x9f\250","\360\235\237\xa9","\360\x9d\237\252","\xf0\x9d\x9f\253","\xf0\235\x9f\242"
    );
    $punnychar = array(
        "a", "b", "\341\xb4\x84", "\xc9\227", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "\xcf\x81", "q", "r", "s", "t", "\317\x85", "\xd1\265", "\311\257", "x", "y", "z", "\xce\221", "\xce\222", "C", "D", "\316\225", "\317\x9c", "G", "\xce\x97", "\xce\x99", "\xd0\x88", "\316\232", "L", "\xce\x9c", "\316\235", "\316\237", "\xce\xa1", "Q", "R", "\xd5\x8f", "T", "U", "V", "\324\x9c", "X", "\xce\245", "\316\226", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"
    );
    $stripentities = array(
        "~<.*?>(*SKIP)(*FAIL)|a~","~<.*?>(*SKIP)(*FAIL)|b~","~<.*?>(*SKIP)(*FAIL)|c~","~<.*?>(*SKIP)(*FAIL)|d~","~<.*?>(*SKIP)(*FAIL)|e~","~<.*?>(*SKIP)(*FAIL)|f~","~<.*?>(*SKIP)(*FAIL)|g~","~<.*?>(*SKIP)(*FAIL)|h~","~<.*?>(*SKIP)(*FAIL)|i~","~<.*?>(*SKIP)(*FAIL)|j~","~<.*?>(*SKIP)(*FAIL)|k~","~<.*?>(*SKIP)(*FAIL)|l~","~<.*?>(*SKIP)(*FAIL)|m~","~<.*?>(*SKIP)(*FAIL)|n~","~<.*?>(*SKIP)(*FAIL)|o~","~<.*?>(*SKIP)(*FAIL)|p~","~<.*?>(*SKIP)(*FAIL)|q~","~<.*?>(*SKIP)(*FAIL)|r~","~<.*?>(*SKIP)(*FAIL)|s~","~<.*?>(*SKIP)(*FAIL)|t~","~<.*?>(*SKIP)(*FAIL)|u~","~<.*?>(*SKIP)(*FAIL)|v~","~<.*?>(*SKIP)(*FAIL)|w~","~<.*?>(*SKIP)(*FAIL)|x~","~<.*?>(*SKIP)(*FAIL)|y~","~<.*?>(*SKIP)(*FAIL)|z~","~<.*?>(*SKIP)(*FAIL)|A~","~<.*?>(*SKIP)(*FAIL)|B~","~<.*?>(*SKIP)(*FAIL)|C~","~<.*?>(*SKIP)(*FAIL)|D~","~<.*?>(*SKIP)(*FAIL)|E~","~<.*?>(*SKIP)(*FAIL)|F~","~<.*?>(*SKIP)(*FAIL)|G~","~<.*?>(*SKIP)(*FAIL)|H~","~<.*?>(*SKIP)(*FAIL)|I~","~<.*?>(*SKIP)(*FAIL)|J~","~<.*?>(*SKIP)(*FAIL)|K~","~<.*?>(*SKIP)(*FAIL)|L~","~<.*?>(*SKIP)(*FAIL)|M~","~<.*?>(*SKIP)(*FAIL)|N~","~<.*?>(*SKIP)(*FAIL)|O~","~<.*?>(*SKIP)(*FAIL)|P~","~<.*?>(*SKIP)(*FAIL)|Q~","~<.*?>(*SKIP)(*FAIL)|R~","~<.*?>(*SKIP)(*FAIL)|S~","~<.*?>(*SKIP)(*FAIL)|T~","~<.*?>(*SKIP)(*FAIL)|U~","~<.*?>(*SKIP)(*FAIL)|V~","~<.*?>(*SKIP)(*FAIL)|W~","~<.*?>(*SKIP)(*FAIL)|X~","~<.*?>(*SKIP)(*FAIL)|Y~","~<.*?>(*SKIP)(*FAIL)|Z~"
    );
    $entitieschar = array(
        "&#97;","&#98;","&#99;","&#100;","&#101;","&#102;","&#103;","&#104;","&#105;","&#106;","&#107;","&#108;","&#109;","&#110;","&#111;","&#112;","&#113;","&#114;","&#115;","&#116;","&#117;","&#118;","&#119;","&#120;","&#121;","&#122;","&#65;","&#66;","&#67;","&#68;","&#69;","&#70;","&#71;","&#72;","&#73;","&#74;","&#75;","&#76;","&#77;","&#78;","&#79;","&#80;","&#81;","&#82;","&#83;","&#84;","&#85;","&#86;","&#87;","&#88;","&#89;","&#90;"
    );
    switch ($type)
    {
        case "emailuser":
            $result = ucfirst(explode("@", $data)[0]);
            break;

        case "emaildomain":
            $temp = explode("@", $data)[1];
            $result = ucfirst(explode(".", $temp)[0]);
            break;

        case "emaildomainfull":
            $result = explode("@", $data)[1];
            break;

        case "emailcencored":
            $temp = explode("@", $data);
            $result = "" . substr($temp[0], 0, 5) . "****@" . $temp[1] . "";
            break;

        case "addparam":
            $randparam = substr(str_shuffle("abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ") , 1, rand(8,32));
            $result = $data . "?trackingid=" . $randparam . "&signature=newsletter";
            break;

        case "encryptlink":
            $entitieslink = array("/a/","/b/","/c/","/d/","/e/","/f/","/g/","/h/","/i/","/j/","/k/","/l/","/m/","/n/","/o/","/p/","/q/","/r/","/s/","/t/","/u/","/v/","/w/","/x/","/y/","/z/","/A/","/B/","/C/","/D/","/E/","/F/","/G/","/H/","/I/","/J/","/K/","/L/","/M/","/N/","/O/","/P/","/Q/","/R/","/S/","/T/","/U/","/V/","/W/","/X/","/Y/","/Z/"
            );
            $exlink = explode("://", $data);
            $enlink = preg_replace($entitieslink, $entitieschar, $exlink[1]);
            $result = $exlink[0] . "://" . $enlink;
            break;

        case "unicode":
            $result = preg_replace($strip, $unicodenormal, $data);
            break;

        case "unicodebold":
            $result = preg_replace($strip, $unicodebold, $data);
            break;

        case "unicodeitalic":
            $result = preg_replace($strip, $unicodeitalic, $data);
            break;

        case "punnycode":
            $result = preg_replace($strip, $punnychar, $data);
            break;

        case "entities":
            $result = preg_replace($stripentities, $entitieschar, $data);
            break;

        case "encryptattachment":
            $escaper = [ "a" => "%61", "b" => "%62", "c" => "%63", "d" => "%64", "e" => "%65", "f" => "%66", "g" => "%67", "h" => "%68", "i" => "%69", "j" => "%6A", "k" => "%6B", "l" => "%6C", "m" => "%6D", "n" => "%6E", "o" => "%6F", "p" => "%70", "q" => "%71", "r" => "%72", "s" => "%73", "t" => "%74", "u" => "%75", "v" => "%76", "w" => "%77", "x" => "%78", "y" => "%79", "z" => "%7A", "A" => "%41", "B" => "%42", "C" => "%43", "D" => "%44", "E" => "%45", "F" => "%46", "G" => "%47", "H" => "%48", "I" => "%49", "J" => "%4A", "K" => "%4B", "L" => "%4C", "M" => "%4D", "N" => "%4E", "O" => "%4F", "P" => "%50", "Q" => "%51", "R" => "%52", "S" => "%53", "T" => "%54", "U" => "%55", "V" => "%56", "W" => "%57", "X" => "%58", "Y" => "%59", "Z" => "%5A", "0" => "%30", "1" => "%31", "2" => "%32", "3" => "%33", "4" => "%34", "5" => "%35", "6" => "%36", "7" => "%37", "8" => "%38", "9" => "%39", "!" => "%21", '"' => "%22", "#" => "%23", "$" => "%24", "%" => "%25", "&" => "%26", "'" => "%27", "(" => "%28", ")" => "%29", "=" => "%3D", "~" => "%7E", "|" => "%7C", "@" => "%40", "[" => "%5B", ";" => "%3B", ":" => "%3A", "]" => "%5D", "," => "%2C", "." => "%2E", "/" => "%2F", "_" => "%5F", "`" => "%60", "{" => "%7B", "+" => "%2B", "*" => "%2A", "}" => "%7D", "<" => "%3C", ">" => "%3E", "?" => "%3F", "-" => "%2D", "^" => "%5E", "\r" => "%0A", "\n" => "%0A", " " => "%20" ];
            $data = strtr($data, $escaper);
            $kutip = '"';
            $result = "<script language=".$kutip."javascript".$kutip.">document.write(unescape('".$data."'));</script>";
            break;

        default:
            $result = false;
            break;
    }

    return $result;
}

function generatestring($type, $length, $kind)
{
    switch ($type)
    {
        case 'number':
            $res = '0123456789';
            break;
        case 'letternumber':
            $res = 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            break;
        case 'letter':
            $res = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            break;
        case 'blank':
            $res = ' ­ ͏ ؜ ᠎ ​ ‌ ‍ ‎ ‏ ⁠ ⁡ ⁢ ⁣ ⁤ ⁪ ⁫ ⁬ ⁭ ⁮ ⁯ ﻿ 𝅳 𝅴 𝅵 𝅶 𝅶 𝅷 𝅸 𝅹 𝅺';
            break;
        default:
            $res = false;
            break;
    }
    $strlen = strlen($res);
    $str = '';
    for ($i = 0;$i < $length;$i++)
    {
        $str .= $res[rand(0, $strlen - 1) ];
    }
    if ($kind == 'up')
    {
        return strtoupper($str);
    }
    else if ($kind == 'low')
    {
        return strtolower($str);
    }
    else if ($type == 'number')
    {
        return $str;
    }
    else
    {
        return $str;
    }
}
function random($body)
{
    preg_match_all("/##(.*?)##/", $body, $match);

    foreach ($match[1] as $key => $value)
    {
        $buff = explode("_", $value);
        $getrand = generatestring($buff[0], $buff[2], $buff[1]);
        $body = str_replace($value, $getrand, $body);
    }

    return str_replace('##', '', $body);
}

function generatename($kind)
{
    $firstseed = array('Aaron', 'Abdiel', 'Abdul', 'Abdullah', 'Abe', 'Abel', 'Abelardo', 'Abner', 'Abraham', 'Adalberto', 'Adam', 'Adan', 'Adelbert', 'Adolf', 'Adolfo', 'Adolph', 'Adolphus', 'Adonis', 'Adrain', 'Adrian', 'Adriel', 'Adrien', 'Afton', 'Agustin', 'Ahmad', 'Ahmed', 'Aidan', 'Aiden', 'Akeem', 'Al', 'Alan', 'Albert', 'Alberto', 'Albin', 'Alden', 'Alec', 'Alejandrin', 'Alek', 'Alessandro', 'Alex', 'Alexander', 'Alexandre', 'Alexandro', 'Alexie', 'Alexis', 'Alexys', 'Alexzander', 'Alf', 'Alfonso', 'Alfonzo', 'Alford', 'Alfred', 'Alfredo', 'Ali', 'Allan', 'Allen', 'Alphonso', 'Alvah', 'Alvis', 'Amani', 'Amari', 'Ambrose', 'Americo', 'Amir', 'Amos', 'Amparo', 'Anastacio', 'Anderson', 'Andre', 'Andres', 'Andrew', 'Andy', 'Angel', 'Angelo', 'Angus', 'Anibal', 'Ansel', 'Ansley', 'Anthony', 'Antone', 'Antonio', 'Antwan', 'Antwon', 'Arch', 'Archibald', 'Arden', 'Arely', 'Ari', 'Aric', 'Ariel', 'Arjun', 'Arlo', 'Armand', 'Armando', 'Armani', 'Arnaldo', 'Arne', 'Arno', 'Arnold', 'Arnoldo', 'Arnulfo', 'Aron', 'Art', 'Arthur', 'Arturo', 'Arvel', 'Arvid', 'Ashton', 'August', 'Augustus', 'Aurelio', 'Austen', 'Austin', 'Austyn', 'Avery', 'Axel', 'Ayden', 'Bailey', 'Barney', 'Baron', 'Barrett', 'Barry', 'Bart', 'Bartholome', 'Barton', 'Baylee', 'Beau', 'Bell', 'Ben', 'Benedict', 'Benjamin', 'Bennett', 'Bennie', 'Benny', 'Benton', 'Bernard', 'Bernardo', 'Bernhard', 'Bernie', 'Berry', 'Berta', 'Bertha', 'Bertram', 'Bertrand', 'Bill', 'Billy', 'Blair', 'Blaise', 'Blake', 'Blaze', 'Bo', 'Bobbie', 'Bobby', 'Boris', 'Boyd', 'Brad', 'Braden', 'Bradford', 'Bradley', 'Bradly', 'Brady', 'Braeden', 'Brain', 'Brando', 'Brandon', 'Brandt', 'Brannon', 'Branson', 'Brant', 'Braulio', 'Braxton', 'Brayan', 'Brendan', 'Brenden', 'Brendon', 'Brennan', 'Brennon', 'Brent', 'Bret', 'Brett', 'Brian', 'Brice', 'Brock', 'Broderick', 'Brody', 'Brook', 'Brooks', 'Brown', 'Bruce', 'Bryce', 'Brycen', 'Bryon', 'Buck', 'Bud', 'Buddy', 'Buford', 'Burley', 'Buster', 'Cade', 'Caden', 'Caesar', 'Cale', 'Caleb', 'Camden', 'Cameron', 'Camren', 'Camron', 'Camryn', 'Candelario', 'Candido', 'Carey', 'Carleton', 'Carlo', 'Carlos', 'Carmel', 'Carmelo', 'Carmine', 'Carol', 'Carroll', 'Carson', 'Carter', 'Cary', 'Casey', 'Casimer', 'Casimir', 'Casper', 'Ceasar', 'Cecil', 'Cedrick', 'Celestino', 'Cesar', 'Chad', 'Chadd', 'Chadrick', 'Chaim', 'Chance', 'Chandler', 'Charles', 'Charley', 'Charlie', 'Chase', 'Chauncey', 'Chaz', 'Chelsey', 'Chesley', 'Chester', 'Chet', 'Chris', 'Christ', 'Christian', 'Christop', 'Christophe', 'Christopher', 'Cicero', 'Cielo', 'Clair', 'Clark', 'Claud', 'Claude', 'Clay', 'Clemens', 'Clement', 'Cleo', 'Cletus', 'Cleve', 'Cleveland', 'Clifford', 'Clifton', 'Clint', 'Clinton', 'Clovis', 'Cloyd', 'Clyde', 'Coby', 'Cody', 'Colby', 'Cole', 'Coleman', 'Colin', 'Collin', 'Colt', 'Colten', 'Colton', 'Columbus', 'Conner', 'Connor', 'Conor', 'Conrad', 'Constantin', 'Consuelo', 'Cooper', 'Corbin', 'Cordelia', 'Cordell', 'Cornelius', 'Cornell', 'Cortez', 'Cory', 'Coty', 'Coy', 'Craig', 'Crawford', 'Cristian', 'Cristina', 'Cristobal', 'Cristopher', 'Cruz', 'Cullen', 'Curt', 'Curtis', 'Cyril', 'Cyrus', 'Dagmar', 'Dale', 'Dallas', 'Dallin', 'Dalton', 'Dameon', 'Damian', 'Damien', 'Damion', 'Damon', 'Dan', 'Dane', 'Dangelo', 'Dangelo', 'Danial', 'Danny', 'Dante', 'Daren', 'Darian', 'Darien', 'Dario', 'Darion', 'Darius', 'Daron', 'Darrel', 'Darrell', 'Darren', 'Darrick', 'Darrin', 'Darrion', 'Darron', 'Darryl', 'Darwin', 'Daryl', 'Dashawn', 'Dave', 'David', 'Davin', 'Davion', 'Davon', 'Davonte', 'Dawson', 'Dax', 'Dayne', 'Dayton', 'Dean', 'Deangelo', 'Declan', 'Dedric', 'Dedrick', 'Dee', 'Deion', 'Dejon', 'Dejuan', 'Delaney', 'Delbert', 'Dell','Delmer', 'Demarco', 'Demarcus', 'Demario', 'Demetrius', 'Demond', 'Denis', 'Dennis', 'Deon', 'Deondre', 'Deontae', 'Deonte', 'Dereck', 'Derek', 'Derick', 'Deron', 'Derrick', 'Deshaun', 'Deshawn', 'Desmond', 'Destin', 'Devan', 'Devante', 'Deven', 'Devin', 'Devon', 'Devonte', 'Devyn', 'Dewayne', 'Dewitt', 'Dexter', 'Diamond', 'Diego', 'Dillan', 'Dillon', 'Dimitri', 'Dino', 'Dion', 'Dock','Domenic', 'Domenick', 'Domenico', 'Domingo', 'Dominic', 'Don', 'Donald', 'Donato', 'Donavon', 'Donnell', 'Donnie', 'Donny', 'Dorcas', 'Dorian', 'Doris', 'Dorthy', 'Doug', 'Douglas', 'Doyle', 'Drake', 'Dudley', 'Duncan', 'Durward', 'Dustin', 'Dusty', 'Dwight', 'Dylan', 'Earl', 'Earnest', 'Easter', 'Easton', 'Ed', 'Edd', 'Eddie', 'Edgar', 'Edgardo', 'Edison', 'Edmond', 'Edmund', 'Eduardo', 'Edward', 'Edwardo', 'Edwin', 'Efrain', 'Efren', 'Einar', 'Eino', 'Eladio', 'Elbert', 'Eldon', 'Eldred', 'Eleazar', 'Eli', 'Elian', 'Elias', 'Eliezer', 'Elijah', 'Eliseo', 'Elliot', 'Elliott', 'Ellis', 'Ellsworth', 'Elmer', 'Elmo', 'Elmore', 'Eloy', 'Elroy', 'Elton', 'Elvis', 'Elwin', 'Elwyn', 'Emanuel', 'Emerald', 'Emerson', 'Emery', 'Emil', 'Emile', 'Emiliano', 'Emilio', 'Emmanuel', 'Emmet', 'Emmett', 'Emmitt', 'Emory', 'Enid', 'Enoch', 'Enos', 'Enrico', 'Enrique', 'Ephraim', 'Eriberto', 'Eric', 'Erich', 'Erick', 'Erik', 'Erin', 'Erling', 'Ernest', 'Ernesto', 'Ernie', 'Ervin', 'Erwin', 'Esteban', 'Estevan', 'Ethan', 'Ethel', 'Eugene', 'Eusebio', 'Evan', 'Evans', 'Everardo', 'Everett', 'Evert', 'Ewald', 'Ewell', 'Ezekiel', 'Ezequiel', 'Ezra', 'Fabian', 'Faustino', 'Fausto', 'Favian', 'Federico', 'Felipe', 'Felix', 'Felton', 'Fermin', 'Fern', 'Fernando', 'Ferne', 'Fidel', 'Filiberto',  'Finn', 'Flavio','Fletcher', 'Florencio', 'Florian', 'Floy', 'Floyd', 'Ford', 'Forest', 'Forrest', 'Foster', 'Francesco', 'Francis', 'Francisco', 'Franco', 'Frank', 'Frankie', 'Franz', 'Fred', 'Freddie', 'Freddy', 'Frederic', 'Frederick', 'Frederik', 'Fredrick', 'Fredy', 'Freeman', 'Friedrich', 'Fritz', 'Furman', 'Gabe', 'Gabriel', 'Gaetano', 'Gage', 'Gardner', 'Garett', 'Garfield', 'Garland', 'Garnet', 'Garnett', 'Garret', 'Garrett', 'Garrick', 'Garrison', 'Garry', 'Garth', 'Gaston', 'Gavin', 'Gay', 'Gayle', 'Gaylord', 'Gene', 'General', 'Gennaro', 'Geo', 'Geoffrey', 'George', 'Geovanni', 'Geovanny', 'Geovany', 'Gerald', 'Gerard', 'Gerardo', 'Gerhard', 'German', 'Gerson', 'Gianni', 'Gideon', 'Gilbert', 'Gilberto', 'Giles', 'Gillian', 'Gino', 'Giovani', 'Giovanni', 'Giovanny','Giuseppe', 'Glen', 'Glennie', 'Godfrey', 'Golden', 'Gonzalo', 'Gordon', 'Grady', 'Graham', 'Grant', 'Granville', 'Grayce', 'Grayson', 'Green', 'Greg', 'Gregg', 'Gregorio', 'Gregory', 'Greyson', 'Griffin', 'Grover', 'Guido', 'Guillermo', 'Guiseppe', 'Gunnar', 'Gunner', 'Gus', 'Gussie', 'Gust', 'Gustave', 'Guy', 'Hadley', 'Hailey', 'Hal', 'Haleigh', 'Haley', 'Halle', 'Hank', 'Hans', 'Hardy', 'Harley', 'Harmon', 'Harold', 'Harrison', 'Harry', 'Harvey', 'Haskell', 'Hassan', 'Hayden', 'Hayley', 'Hazel', 'Hazle', 'Heber', 'Hector', 'Helmer', 'Henderson', 'Henri', 'Henry', 'Herbert', 'Herman', 'Hermann', 'Herminio', 'Hershel', 'Hester', 'Hilario', 'Hilbert', 'Hillard', 'Hilton', 'Hipolito', 'Hiram', 'Hobart', 'Holden', 'Hollis', 'Horace', 'Horacio', 'Houston', 'Howard', 'Howell', 'Hoyt', 'Hubert', 'Hudson', 'Hugh', 'Humberto', 'Hunter', 'Hyman', 'Ian', 'Ibrahim', 'Ignacio', 'Ignatius', 'Ike', 'Imani', 'Immanuel', 'Irving', 'Irwin', 'Isaac', 'Isac', 'Isadore', 'Isai', 'Isaiah', 'Isaias', 'Isidro', 'Ismael', 'Isom', 'Israel', 'Issac', 'Izaiah', 'Jabari', 'Jace', 'Jacey', 'Jacinto', 'Jack', 'Jackson', 'Jacques', 'Jaden', 'Jadon', 'Jaeden', 'Jaiden', 'Jaime', 'Jairo', 'Jake', 'Jakob', 'Jaleel', 'Jalen', 'Jalon', 'Jamaal', 'Jamal', 'Jamar', 'Jamarcus', 'Jamel', 'Jameson', 'Jamey', 'Jamie', 'Jamil', 'Jamir', 'Jamison', 'Jan', 'Janick', 'Jaquan', 'Jared', 'Jaren', 'Jarod', 'Jaron', 'Jarred', 'Jarrell', 'Jarret', 'Jarrett', 'Jarrod', 'Jarvis', 'Jasen', 'Jasmin', 'Jason', 'Jasper', 'Javier', 'Javon', 'Javonte', 'Jay', 'Jayce', 'Jaycee',  'Jayde', 'Jayden', 'Jaydon', 'Jaylan', 'Jaylen', 'Jaylin', 'Jaylon', 'Jayme', 'Jayson', 'Jean', 'Jed', 'Jedediah', 'Jedidiah', 'Jeff', 'Jefferey', 'Jeffery', 'Jeffrey', 'Jeffry', 'Jennings', 'Jensen', 'Jerad', 'Jerald', 'Jeramie', 'Jeramy', 'Jerel', 'Jeremie', 'Jeremy', 'Jermain', 'Jermey', 'Jerod', 'Jerome', 'Jeromy', 'Jerrell', 'Jerrod', 'Jerrold', 'Jerry', 'Jess', 'Jesse', 'Jessie', 'Jessy', 'Jesus', 'Jett', 'Jettie', 'Jevon', 'Jillian', 'Jimmie', 'Jimmy', 'Jo', 'Joan', 'Joany', 'Joaquin', 'Jocelyn', 'Joe', 'Joel',  'Joesph', 'Joey', 'Johan', 'Johann', 'Johathan', 'John', 'Johnathan', 'Johnathon', 'Johnnie', 'Johnny', 'Johnpaul', 'Johnson', 'Jon', 'Jonas', 'Jonatan', 'Jonathan', 'Jonathon', 'Jordan', 'Jordi', 'Jordon', 'Jordy', 'Jordyn', 'Jorge', 'Jose', 'Joseph', 'Josh', 'Joshua', 'Joshuah', 'Josiah', 'Josue', 'Jovan', 'Jovani', 'Jovanny', 'Jovany', 'Judah', 'Judd', 'Judge', 'Judson', 'Jules', 'Julian', 'Julien', 'Julio', 'Julius', 'Junior', 'Junius', 'Justen', 'Justice', 'Juston', 'Justus', 'Justyn', 'Juvenal', 'Juwan', 'Kacey', 'Kade', 'Kaden', 'Kadin', 'Kale', 'Kaleb', 'Kaleigh', 'Kaley', 'Kameron', 'Kamren', 'Kamron', 'Kamryn', 'Kane', 'Kareem', 'Karl', 'Karley', 'Karson', 'Kay', 'Kayden', 'Kayleigh', 'Kayley', 'Keagan', 'Keanu', 'Keaton', 'Keegan', 'Keeley', 'Keenan', 'Keith', 'Kellen', 'Kelley', 'Kelton', 'Kelvin', 'Ken', 'Kendall', 'Kendrick', 'Kennedi', 'Kennedy', 'Kenneth', 'Kennith', 'Kenny', 'Kenton', 'Kenyon', 'Keon', 'Keshaun', 'Keshawn', 'Keven', 'Kevin', 'Kevon', 'Keyon', 'Keyshawn', 'Khalid', 'Khalil', 'Kian', 'Kiel', 'Kieran', 'Kiley', 'Kim', 'King', 'Kip', 'Kirk', 'Kobe', 'Koby', 'Kody', 'Kolby', 'Kole', 'Korbin', 'Korey', 'Kory', 'Kraig', 'Kris', 'Kristian', 'Kristofer', 'Kristoffer', 'Kristopher', 'Kurt', 'Kurtis', 'Kyle', 'Kyleigh', 'Kyler', 'Ladarius', 'Lafayette', 'Lamar', 'Lambert', 'Lamont', 'Lance', 'Landen', 'Lane', 'Laron', 'Larry', 'Larue', 'Laurel', 'Lavern', 'Laverna', 'Laverne', 'Lavon', 'Lawrence', 'Lawson', 'Layne', 'Lazaro', 'Lee', 'Leif', 'Leland', 'Lemuel', 'Lennie', 'Lenny', 'Leo', 'Leon', 'Leonard', 'Leonardo', 'Leone', 'Leonel', 'Leopold', 'Leopoldo', 'Lesley', 'Lester', 'Levi', 'Lew', 'Lewis', 'Lexus', 'Liam', 'Lincoln', 'Lindsey', 'Linwood', 'Lionel', 'Lisandro', 'Llewellyn', 'Lloyd', 'Logan', 'Lon', 'London', 'Lonnie', 'Lonny', 'Lonzo', 'Lorenz', 'Lorenza', 'Lorenzo', 'Louie', 'Louisa', 'Lourdes', 'Louvenia', 'Lowell', 'Loy', 'Loyal', 'Lucas', 'Luciano', 'Lucio', 'Lucious', 'Lucius', 'Ludwig', 'Luigi', 'Luis', 'Lukas', 'Lula', 'Luther', 'Lyric', 'Mac', 'Macey', 'Mack', 'Mackenzie', 'Madisen', 'Madison', 'Madyson', 'Magnus', 'Major', 'Makenna', 'Malachi', 'Malcolm', 'Mallory', 'Manley', 'Manuel', 'Manuela', 'Marc', 'Marcel', 'Marcelino', 'Marcellus', 'Marcelo', 'Marco', 'Marcos', 'Marcus', 'Mariano', 'Mario', 'Mark', 'Markus', 'Marley', 'Marlin', 'Marlon', 'Marques', 'Marquis', 'Marshall', 'Martin', 'Marty', 'Marvin', 'Mason', 'Mateo', 'Mathew', 'Mathias', 'Matt', 'Matteo', 'Maurice', 'Mauricio', 'Maverick', 'Mavis', 'Max', 'Maxime', 'Maximilian', 'Maximillian', 'Maximo', 'Maximus', 'Maxine', 'Maxwell', 'Maynard', 'Mckenna', 'Mckenzie', 'Mekhi', 'Melany', 'Melvin', 'Melvina', 'Merl', 'Merle', 'Merlin', 'Merritt', 'Mervin', 'Micah', 'Michael', 'Michale', 'Micheal', 'Michel', 'Miguel', 'Mike', 'Mikel', 'Milan', 'Miles', 'Milford', 'Miller', 'Milo', 'Milton', 'Misael', 'Mitchel', 'Mitchell', 'Modesto', 'Mohamed', 'Mohammad', 'Mohammed', 'Moises', 'Monroe', 'Monserrat', 'Monserrate', 'Montana', 'Monte', 'Monty', 'Morgan', 'Moriah', 'Morris', 'Mortimer', 'Morton', 'Mose', 'Moses', 'Moshe', 'Muhammad', 'Murl', 'Murphy', 'Murray', 'Mustafa', 'Myles',  'Myrl', 'Myron', 'Napoleon', 'Narciso', 'Nash', 'Nasir', 'Nat', 'Nathan', 'Nathanael', 'Nathanial', 'Nathaniel', 'Nathen', 'Neal', 'Ned', 'Neil', 'Nels', 'Nelson', 'Nestor', 'Newell', 'Newton', 'Nicholas', 'Nicholaus', 'Nick', 'Nicklaus', 'Nickolas', 'Nico', 'Nicola', 'Nicolas', 'Nigel', 'Nikko', 'Niko', 'Nikolas', 'Nils', 'Noah', 'Noble', 'Noe', 'Noel', 'Nolan', 'Norbert', 'Norberto', 'Norris', 'Norval', 'Norwood', 'Obie', 'Oda', 'Odell', 'Okey', 'Ola', 'Olaf', 'Ole', 'Olen', 'Olin', 'Oliver', 'Omari', 'Omer', 'Oral', 'Oran', 'Oren', 'Orin', 'Orion', 'Orland', 'Orlando', 'Orlo', 'Orrin', 'Orval', 'Orville', 'Osbaldo', 'Osborne', 'Oscar', 'Osvaldo', 'Oswald', 'Oswaldo', 'Otho', 'Otis', 'Ottis', 'Otto', 'Owen', 'Pablo', 'Paolo', 'Paris', 'Parker', 'Patrick', 'Paul', 'Paxton', 'Payton', 'Pedro', 'Percival', 'Percy', 'Perry', 'Pete', 'Peter', 'Peyton', 'Philip', 'Pierce', 'Pierre', 'Pietro', 'Porter', 'Presley', 'Preston', 'Price', 'Prince', 'Quentin', 'Quincy', 'Quinn', 'Quinten', 'Quinton', 'Rafael', 'Raheem', 'Rahul', 'Raleigh', 'Ralph', 'Ramiro', 'Ramon', 'Randal', 'Randall', 'Randi', 'Randy', 'Ransom', 'Raoul', 'Raphael', 'Rashad', 'Rashawn', 'Rasheed', 'Raul', 'Raven', 'Ray', 'Raymond', 'Raymundo', 'Reagan', 'Reece', 'Reed', 'Reese', 'Regan', 'Reggie', 'Reginald', 'Reid', 'Reilly','Reinhold', 'Remington', 'Rene', 'Reuben', 'Rex', 'Rey', 'Reyes', 'Reymundo', 'Reynold', 'Rhett', 'Rhiannon', 'Ricardo', 'Richard', 'Richie', 'Richmond', 'Rick', 'Rickey', 'Rickie', 'Ricky', 'Rico', 'Rigoberto', 'Riley', 'Robb', 'Robbie', 'Robert', 'Roberto', 'Robin', 'Rocio', 'Rocky', 'Rod', 'Roderick', 'Rodger', 'Rodolfo', 'Rodrick', 'Rodrigo', 'Roel', 'Rogelio', 'Roger', 'Rogers', 'Rolando', 'Rollin', 'Roman', 'Ron', 'Ronaldo', 'Ronny', 'Roosevelt', 'Rory', 'Rosario', 'Roscoe', 'Rosendo', 'Ross', 'Rowan', 'Rowland', 'Roy', 'Royal', 'Royce', 'Ruben', 'Rudolph', 'Rudy', 'Rupert', 'Russ', 'Russel', 'Russell', 'Rusty', 'Ryan', 'Ryann', 'Ryder', 'Rylan', 'Ryleigh', 'Ryley', 'Sage', 'Saige', 'Salvador', 'Salvatore', 'Sam', 'Samir', 'Sammie', 'Sammy', 'Samson', 'Sanford', 'Santa', 'Santiago', 'Santino', 'Santos', 'Saul', 'Savion', 'Schuyler', 'Scot', 'Scottie', 'Scotty', 'Seamus', 'Sean', 'Sebastian', 'Sedrick', 'Selmer', 'Seth', 'Shad', 'Shane', 'Shaun', 'Shawn', 'Shayne', 'Sheldon', 'Sheridan', 'Sherman', 'Sherwood', 'Sid', 'Sidney', 'Sigmund', 'Sigrid', 'Sigurd', 'Silas', 'Sim', 'Simeon', 'Skye', 'Skylar', 'Sofia', 'Soledad', 'Solon', 'Sonny', 'Spencer', 'Stan', 'Stanford', 'Stanley', 'Stanton', 'Stefan', 'Stephan', 'Stephen', 'Stephon', 'Sterling', 'Steve', 'Stevie', 'Stewart', 'Stone', 'Stuart', 'Sven', 'Sydney', 'Sylvan', 'Sylvester', 'Tad', 'Talon', 'Tanner', 'Tate', 'Tatum', 'Taurean', 'Tavares', 'Taylor', 'Ted', 'Terence', 'Terrance', 'Terrell', 'Terrence', 'Terrill', 'Terry', 'Tevin', 'Thad', 'Thaddeus', 'Theo', 'Theodore', 'Theron', 'Thomas', 'Thurman', 'Tillman', 'Timmothy', 'Timmy', 'Timothy', 'Tito', 'Titus', 'Tobin', 'Toby', 'Tod', 'Tom', 'Tomas', 'Tommie', 'Toney', 'Toni', 'Tony', 'Torey', 'Torrance', 'Torrey', 'Toy', 'Trace', 'Tracey', 'Travis', 'Travon', 'Tre', 'Tremaine', 'Tremayne', 'Trent', 'Trenton', 'Trever', 'Trevion', 'Trevor', 'Trey',  'Tristian', 'Tristin', 'Triston', 'Troy', 'Trystan', 'Turner','Tyler', 'Tyree', 'Tyreek', 'Tyrel', 'Tyrell', 'Tyrese', 'Tyrique', 'Tyshawn', 'Tyson', 'Ubaldo', 'Ulices', 'Ulises', 'Unique', 'Urban', 'Uriah', 'Uriel', 'Valentin', 'Van', 'Vance', 'Vaughn', 'Vern', 'Verner', 'Vernon', 'Vicente', 'Victor', 'Vidal', 'Vince', 'Vincent', 'Vincenzo', 'Vinnie', 'Virgil', 'Vito', 'Vladimir', 'Wade', 'Waino', 'Waldo', 'Walker', 'Wallace', 'Walter', 'Walton', 'Ward', 'Warren', 'Watson', 'Waylon', 'Wayne', 'Webster', 'Weldon', 'Wellington', 'Wendell', 'Werner', 'Westley', 'Weston', 'Wilber', 'Wilbert', 'Wilburn', 'Wiley', 'Wilford', 'Wilfred', 'Wilfredo', 'Wilfrid', 'Wilhelm', 'Will', 'Willard', 'William', 'Willis', 'Willy', 'Wilmer', 'Wilson', 'Wilton', 'Winfield', 'Winston', 'Woodrow', 'Wyatt', 'Wyman', 'Xavier', 'Xzavier', 'Xander', 'Zachariah', 'Zachary', 'Zachery', 'Zack', 'Zackary', 'Zackery', 'Zakary', 'Zander', 'Zane', 'Zechariah', 'Zion');
    $lastseed = array('Abbott', 'Abernathy', 'Abshire', 'Adams', 'Altenwerth', 'Anderson', 'Ankunding', 'Armstrong', 'Auer', 'Aufderhar', 'Bahringer', 'Bailey', 'Balistreri', 'Barrows', 'Bartell', 'Bartoletti', 'Barton', 'Bashirian', 'Batz', 'Bauch', 'Baumbach', 'Bayer', 'Beahan', 'Beatty', 'Bechtelar', 'Becker', 'Bednar', 'Beer', 'Beier', 'Berge', 'Bergnaum', 'Bergstrom', 'Bernhard', 'Bernier', 'Bins', 'Blanda', 'Blick', 'Block', 'Bode', 'Boehm', 'Bogan', 'Bogisich', 'Borer', 'Bosco', 'Botsford', 'Boyer', 'Boyle', 'Bradtke', 'Brakus', 'Braun', 'Breitenberg', 'Brekke', 'Brown', 'Bruen', 'Buckridge', 'Carroll', 'Carter', 'Cartwright', 'Casper', 'Cassin', 'Champlin', 'Christiansen', 'Cole', 'Collier', 'Collins', 'Conn', 'Connelly', 'Conroy', 'Considine', 'Corkery', 'Cormier', 'Corwin', 'Cremin', 'Crist', 'Crona', 'Cronin', 'Crooks', 'Cruickshank', 'Cummerata', 'Cummings', 'Dach', 'DAmore', 'Daniel', 'Dare', 'Daugherty', 'Davis', 'Deckow', 'Denesik', 'Dibbert', 'Dickens', 'Dicki', 'Dickinson', 'Dietrich', 'Donnelly', 'Dooley', 'Douglas', 'Doyle', 'DuBuque', 'Durgan', 'Ebert', 'Effertz', 'Eichmann', 'Emard', 'Emmerich', 'Erdman', 'Ernser', 'Fadel', 'Fahey', 'Farrell', 'Fay', 'Feeney', 'Feest', 'Feil', 'Ferry', 'Fisher', 'Flatley', 'Frami', 'Franecki', 'Friesen', 'Fritsch', 'Funk', 'Gaylord', 'Gerhold', 'Gerlach', 'Gibson', 'Gislason', 'Gleason', 'Gleichner', 'Glover', 'Goldner', 'Goodwin', 'Gorczany', 'Gottlieb', 'Goyette', 'Grady', 'Graham', 'Grant', 'Green', 'Greenfelder', 'Greenholt', 'Grimes', 'Gulgowski', 'Gusikowski', 'Gutkowski', 'Gutmann', 'Haag', 'Hackett', 'Hagenes', 'Hahn', 'Haley', 'Halvorson', 'Hamill', 'Hammes', 'Hand', 'Hane', 'Hansen', 'Harber', 'Harris', 'Hartmann', 'Harvey', 'Hauck', 'Hayes', 'Heaney', 'Heathcote', 'Hegmann', 'Heidenreich', 'Heller', 'Herman', 'Hermann', 'Hermiston', 'Herzog', 'Hessel', 'Hettinger', 'Hickle', 'Hill', 'Hills', 'Hilpert', 'Hintz', 'Hirthe', 'Hodkiewicz', 'Hoeger', 'Homenick', 'Hoppe', 'Howe', 'Howell', 'Hudson', 'Huel', 'Huels', 'Hyatt', 'Jacobi', 'Jacobs', 'Jacobson', 'Jakubowski', 'Jaskolski', 'Jast', 'Jenkins', 'Jerde', 'Johns', 'Johnson', 'Johnston', 'Jones', 'Kassulke', 'Kautzer', 'Keebler', 'Keeling', 'Kemmer', 'Kerluke', 'Kertzmann', 'Kessler', 'Kiehn', 'Kihn', 'Kilback', 'King', 'Kirlin', 'Klein', 'Kling', 'Klocko', 'Koch', 'Koelpin', 'Koepp', 'Kohler', 'Konopelski', 'Koss', 'Kovacek', 'Kozey', 'Krajcik', 'Kreiger', 'Kris', 'Kshlerin', 'Kub', 'Kuhic', 'Kuhlman', 'Kuhn', 'Kulas', 'Kunde', 'Kunze', 'Kuphal', 'Kutch', 'Kuvalis', 'Labadie', 'Lakin', 'Lang', 'Langosh', 'Langworth', 'Larkin', 'Larson', 'Leannon', 'Lebsack', 'Ledner', 'Leffler', 'Legros', 'Lehner', 'Lemke', 'Lesch', 'Leuschke', 'Lind', 'Lindgren', 'Littel', 'Little', 'Lockman', 'Lowe', 'Lubowitz', 'Lueilwitz', 'Luettgen', 'Lynch', 'Macejkovic', 'Maggio', 'Mann', 'Mante', 'Marks', 'Marquardt', 'Marvin', 'Mayer', 'Mayert', 'McClure', 'McCullough', 'McDermott', 'McGlynn', 'McKenzie', 'McLaughlin', 'Medhurst', 'Mertz', 'Metz', 'Miller', 'Mills', 'Mitchell', 'Moen', 'Mohr', 'Monahan', 'Moore', 'Morar', 'Morissette', 'Mosciski', 'Mraz', 'Mueller', 'Muller', 'Murazik', 'Murphy', 'Murray', 'Nader', 'Nicolas', 'Nienow', 'Nikolaus', 'Nitzsche', 'Nolan', 'Oberbrunner', 'OConnell', 'OConner', 'OHara', 'OKeefe', 'OKon', 'Okuneva', 'Olson', 'Ondricka', 'OReilly', 'Orn', 'Ortiz', 'Osinski', 'Pacocha', 'Padberg', 'Pagac', 'Parisian', 'Parker', 'Paucek', 'Pfannerstill', 'Pfeffer', 'Pollich', 'Pouros', 'Powlowski', 'Predovic', 'Price', 'Prohaska', 'Prosacco', 'Purdy', 'Quigley', 'Quitzon', 'Rath', 'Ratke', 'Rau', 'Raynor', 'Reichel', 'Reichert', 'Reilly', 'Reinger', 'Rempel', 'Renner', 'Reynolds', 'Rice', 'Rippin', 'Ritchie', 'Robel', 'Roberts', 'Rodriguez', 'Rogahn', 'Rohan', 'Rolfson', 'Romaguera', 'Roob', 'Rosenbaum', 'Rowe', 'Ruecker', 'Runolfsdottir', 'Runolfsson', 'Runte', 'Russel', 'Rutherford', 'Ryan', 'Sanford', 'Satterfield', 'Sauer', 'Sawayn', 'Schaden', 'Schaefer', 'Schamberger', 'Schiller', 'Schimmel', 'Schinner', 'Schmeler', 'Schmidt', 'Schmitt', 'Schneider', 'Schoen', 'Schowalter', 'Schroeder', 'Schulist', 'Schultz', 'Schumm', 'Schuppe', 'Schuster', 'Senger', 'Shanahan', 'Shields', 'Simonis', 'Sipes', 'Skiles', 'Smith', 'Smitham', 'Spencer', 'Spinka', 'Sporer', 'Stamm', 'Stanton', 'Stark', 'Stehr', 'Steuber', 'Stiedemann', 'Stokes', 'Stoltenberg', 'Stracke', 'Streich', 'Stroman', 'Strosin', 'Swaniawski', 'Swift', 'Terry', 'Thiel', 'Thompson', 'Tillman', 'Torp', 'Torphy', 'Towne', 'Toy', 'Trantow', 'Tremblay', 'Treutel', 'Tromp', 'Turcotte', 'Turner', 'Ullrich', 'Upton', 'Vandervort', 'Veum', 'Volkman', 'Von', 'VonRueden', 'Waelchi', 'Walker', 'Walsh', 'Walter', 'Ward', 'Waters', 'Watsica', 'Weber', 'Wehner', 'Weimann', 'Weissnat', 'Welch', 'West', 'White', 'Wiegand', 'Wilderman', 'Wilkinson', 'Will', 'Williamson', 'Willms', 'Windler', 'Wintheiser', 'Wisoky', 'Wisozk', 'Witting', 'Wiza', 'Wolf', 'Wolff', 'Wuckert', 'Wunsch', 'Wyman', 'Yost', 'Yundt', 'Zboncak', 'Zemlak', 'Ziemann', 'Zieme', 'Zulauf');
    $domainseed = array("hotmail.com", "outlook.com", "gmail.com", "yahoo.com");

    $firstname = $firstseed[array_rand($firstseed)];
    $lastname = $lastseed[array_rand($lastseed)];
    $domain = $domainseed[array_rand($domainseed)];

    $email = strtolower($firstname . "" . $lastname . "@" . $domain);
    $email = str_ireplace(" ", "", $email);
    $name = $firstname . " " . $lastname;

    switch ($kind)
    {
        case "name":
            $data = $name;
            break;

        case "email":
            $data = $email;
            break;

        default:
            $data = "";
            break;
    }

    return $data;
}