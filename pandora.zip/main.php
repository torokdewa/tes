<?php
error_reporting(E_ALL);

require_once "Modules/Function.php";
include "Pandora/Construct_Main.php";
require_once "settings.php";

date_default_timezone_set($pandora_config["TimeZone"]);

$m = $pandora_config["ColorMode"];
$r = "red"; $g = "green"; $b = "blue"; $p = "purple"; $c = "cyan"; $y = "yellow";

echo "
    ".c($b, "===============================================================", $m)."
    ".c($b, "+ ", $m)."".c($g, "██████╗  █████╗ ███╗   ██╗██████╗  ██████╗ ██████╗  █████╗ ", $m)."".c($b, " +", $m)."
    ".c($b, "+ ", $m)."".c($g, "██╔══██╗██╔══██╗████╗  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗", $m)."".c($b, " +", $m)."
    ".c($b, "+ ", $m)."".c($g, "██████╔╝███████║██╔██╗ ██║██║  ██║██║   ██║██████╔╝███████║", $m)."".c($b, " +", $m)."
    ".c($b, "+ ", $m)."".c($g, "██╔═══╝ ██╔══██║██║╚██╗██║██║  ██║██║   ██║██╔══██╗██╔══██║", $m)."".c($b, " +", $m)."
    ".c($b, "+ ", $m)."".c($g, "██║     ██║  ██║██║ ╚████║██████╔╝╚██████╔╝██║  ██║██║  ██║", $m)."".c($b, " +", $m)."
    ".c($b, "+ ", $m)."".c($g, "╚═╝     ╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝", $m)."".c($b, " +", $m)."
    ".c($b, "===============================================================", $m)."
    ".c($b, "+ ", $m)."".c($y, "TOOLS        : PANDORA ID SENDER               PING : " . rand(5,100) ." MS", $m)."".c($b, " +", $m)."
    ".c($b, "+ ", $m)."".c($y, "VERSION      : 1.0                                         ", $m)."".c($b, " +", $m)."
    ".c($b, "+ ", $m)."".c($y, "LICENSE TYPE : PAID                                        ", $m)."".c($b, " +", $m)."
    ".c($b, "+ ", $m)."".c($y, "STATUS       : OK                                          ", $m)."".c($b, " +", $m)."
    ".c($b, "===============================================================", $m)."
    ".c($b, "+ ", $m)."".c($y, "                  https://pandora-id.vip                   ", $m)."".c($b, " +", $m)."
    ".c($b, "===============================================================", $m)."
    ";

$mailist = file_get_contents("List/" . $pandora_config["MailistFile"]) or die("   Mailist Not Found!");
$mailist = preg_split("/\n|\r\n?/", $mailist);
if ($pandora_config["ClearDuplicate"] == true)
{
    $mailist = array_unique($mailist);
}
$mailist = str_replace(" ", "", $mailist);
$mailist = preg_grep("/[a-z0-9]+([_\.-][a-z0-9]+)*@([a-z0-9]+([\.-][a-z0-9]+)*)+\.[a-z]{2,}/i", $mailist);
$mailistcount = count($mailist);

echo c($c, "\r\n    Total Mailist Detected => " . $mailistcount, $m) . "\r\n";

$continue = scrn("    Continue Sending ? (y/n) : ");
if ($continue != "y")
{
    die(c($r, "    Sending Aborted!", $m) . "\r\n");
}

$smtp = file_get_contents("Smtp/" . $pandora_config["SMTPFile"]) or die("     SMTP Not Found!");
$smtp = preg_split("/\n|\r\n?/", $smtp);
$smtp = array_values(array_filter($smtp));

$no = 1;
$i = 0;
$no_send = 1;
$no_list = 1;
$no_add = 1;

$mailist_split = array_chunk($mailist, $pandora_config["Connection"]);

if ($pandora_send["SendTwoTimes"] == true)
{
    $newlist = [];
    foreach ($mailist_split as $arraykey => $arrayvalue)
    {
        array_push($newlist, $arrayvalue);
        array_push($newlist, $arrayvalue);
    }
    $mailist_split = $newlist;
}

if ($pandora_send["EmailTest"] != null)
{
    if ($pandora_send["TestAfter"] == null)
    {
        die(c($r, "    Test after is empty!", $m) . "\r\n");
    } else {

        $mailtest = array("0" => $pandora_send["EmailTest"]);
        $testafter = $pandora_send["TestAfter"];

        $mailist_split = array_reduce(
            array_map(
                function($i) use($mailtest, $testafter)
                {
                    return count($i) ==  $testafter ? array_merge($i, array($mailtest)) : $i;
                },
                array_chunk($mailist_split, $testafter)
            ),
            function($r, $i)
            {
                return array_merge($r, $i);
            },
            array()
        );
    }
}

foreach ($mailist_split as $key => $list)
{
    $grabsmtps = $smtp[$i % count($smtp)];
    $grabsmtp = explode(",", $grabsmtps);

    $sendmail = PandoraSend($list, $grabsmtps, $pandora_config, $pandora_send);

    if ($sendmail["status"] == "success")
    {
        $sendstatus = c($g, "[SUCCESS]\r\n", $m);
    } else {
        $sendstatus = c($r, "[FAILED] REASON > " . $sendmail["info"] . "\r\n\r\n", $m);
    }

    echo "\r\n" . c($y, "    SENDING " . $no_send . " / " . count($mailist_split), $m) . "\r\n";

    foreach ($list as $keys => $added)
    {
        echo "" . c($b, "    > SENT TO :", $m) . " " . c($c, strtoupper($added), $m) . "\r\n";
        echo "" . c($b, "    > BY SMTP :", $m) . " " . c($g, strtoupper($grabsmtp[0]), $m) . "\r\n";

        if ($sendmail["from"] != null && $sendmail["subject"] != null)
        {
            echo "" . c($b, "    > FROM    :", $m) . " " . c($y, $sendmail["from"], $m) . "\r\n";
            echo "" . c($b, "    > SUBJECT :", $m) . " " . c($p, $sendmail["subject"], $m) . "\r\n";
        }

        echo c($b, "    > STATUS  : ", $m) . $sendstatus;
    }
    $i++;
    $no_send++;
    $no_add++;
    sleep($pandora_config["Delay"]);
}
?>