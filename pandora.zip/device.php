<?php
require_once "Modules/Function.php";

$url = "https://ipecho.net/plain";

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

$deviceid = strtoupper(md5(curl_exec($curl)));
echo c("cyan", "\r\n   YOUR DEVICE ID => " . $deviceid . "\r\n", true);
echo c("red", "\r\n   PLEASE ADD YOUR DEVICE ID TO YOUR MEMBER DASHBOARD!\r\n\r\n", true);