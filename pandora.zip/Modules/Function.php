<?php

require_once __DIR__ . "/../Pandora/Construct.php";

function pandora($data, $timezone, $email, $imagecid, $smtp, $link, $linkparam, $encryptlink, $encryptstring, $encryptattachment, $type)
{
    $dataprocess = processingdata($data, $timezone, $email, $imagecid, $smtp, $link, $linkparam, $encryptlink, $encryptstring, $encryptattachment, $type);

    return $dataprocess;
}

function iCalGenerate()
{
    $mylength = rand(1, 20);
    $mylength2 = rand(1, 20);
    $chars = str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890");
    return '' . substr($chars, 1, $mylength) . ":" . substr($chars, 1, $mylength2) . "";
}

function customrandom($body, $array)
{
    foreach ($array as $key => $value) {
        $getisi = explode("|", $value);
        shuffle($getisi);
        $isinya = $getisi[array_rand($getisi)];
        $body = str_ireplace($key, $isinya, $body);
    }
    return $body;
}

function c($color, $text, $mode)
{
    switch ($color)
    {
        case 'red':
            $colors = "\033[1;31m";
            break;
        case 'green':
            $colors = "\033[1;32m";
            break;
        case 'blue':
            $colors = "\033[1;34m";
            break;
        case 'purple':
            $colors = "\033[1;35m";
            break;
        case 'cyan':
            $colors = "\033[1;36m";
            break;
        case 'yellow':
            $colors = "\033[1;33m";
            break;
        default:
            $colors = "\033[0m";
            break;
    }
    if ($mode == true)
    {
        return $colors . $text . "\033[0m";
    }
    else
    {
        return $text;
    }

}

function scrn($question)
{
    echo $question;
    return rtrim(fgets(STDIN));
}

function sendtags($fromname, $frommail, $subject, $data)
{

    $data = str_ireplace("##fromname##", $fromname, $data);
    $data = str_ireplace("##frommail##", $frommail, $data);
    return str_ireplace("##subject##", $subject, $data);
}