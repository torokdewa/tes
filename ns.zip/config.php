<?php

function generateRandomString($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[random_int(0, $charactersLength - 1)];
    }
    return $randomString;
	
}

$str = generateRandomString(12);

function generateRandomString1($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[random_int(0, $charactersLength - 1)];
    }
    return $randomString;
	
}

$str1 = generateRandomString(20);



$timeset = 'Asia/Jakarta'; // reference for timezone http://php.net/manual/en/timezones.php


$smtp = 'smtp.csv';
$mailist = [
	'file'				=> 'list.txt',
	'removeduplicate'	=> false,
];

$sender_setting = [
	'color'				=> false,
	'Host'				=> 'email-smtp.us-west-1.amazonaws.com', // smtp.gmail.com or smtp-relay.gmail.com email-smtp.us-east-1.amazonaws.com
	'Port'				=> '587',
	'max'				=> '1', // total of emails to send per sending
	'delay'				=> '0', // delay for send
	'charset'			=> 'utf-8',
	'encoding'			=> 'quoted-printable', // quoted-printable or base64 or 7bit or 8bit
	'priority'			=> '3',	// 1=high, 3=normal, 5=low
	'randomparam'		=> true,
	'link'				=> '', // input link here to use a random link fiture
	'header'			=> false,
];

$sender_inbox = [
	#--start--#
	[
		'fname' 				=> 'ayam kfc', // from name 
		'fmail'					=> "ppp@mailbox.phpfusionturkiye.com",
		'subject' 				=> "tes",//Daily Confirmation - Your User Agreements need to be update
		'attachfile'			=> '', // Your PDF File, leave it blank if you wont use it
		'attachname' 			=> "", // Custom your PDF File
		'letter'				=> 'kosong.html',

	],
	#--end--#


];

//$sender_header = array(
//'Return-Path|bounce-HP2v##mix_random_20##@daily.comms.yahoo.net',
//'List-Unsubscribe|mailto:bounce-##mix_random_20##@daily.comms.yahoo.net?subject=list-unsubscribe',
//'Message-ID|HP2v##mix_random_20##@daily.comms.yahoo.net',
//'Feedback-ID|##mix_normal_8##-b12a-49ed-86bb-##mix_normal_12##:028fd102-d5ee-4ef3-a467-1ffe89cbefde:email:epslh1',
//'X-NSS|##mix_normal_8##-b12a-49ed-86bb-##mix_normal_12##',
//); 




?>